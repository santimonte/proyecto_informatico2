import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Imágenes usadas DURANTE la partida (el menú tiene su propia clase,
 * ImagenesMenu, dentro de MenuPrincipal.java).
 *
 * Para cambiar el fondo de una escena, no hace falta tocar este archivo:
 * en GestorEscenas se llama a marcar("habitacion" | "cementerio", ...).
 * Si querés SUMAR un lugar nuevo, agregá el .png en assets/fondos/, cargalo
 * acá abajo y agregá un case nuevo en fondo(...). Lo mismo para expresiones
 * nuevas del personaje: poné los .png en assets/sprites/ y agregalos en
 * sprite(...). Las imágenes que falten simplemente no se dibujan (no rompen el juego).
 */
class ImagenesJuego {

    // Se busca primero respecto a la carpeta desde donde se corre el .jar/.class,
    // y si no está, se usa la ruta absoluta del proyecto (la misma idea que
    // usa ImagenesMenu). Así funciona tanto desde el IDE como desde Windows.
    private static final String RAIZ_RELATIVA = "assets/";
   
    // A: C:\Users\Usuario\Downloads\novelavisual\novelavisual\assets\
    private static final String RAIZ_ABSOLUTA = "C:\\Users\\Usuario\\Downloads\\novelavisual\\novelavisual\\assets\\";
    // =========================================================================

    // ===== Fondos =====
    // "habitacion.png" está escrito "habtacion.png" en el proyecto original;
    // se aceptan ambos nombres para no tener que renombrar el archivo.
    static final BufferedImage FONDO_HABITACION =
            primero("fondos/habitacion.png", "fondos/habtacion.png");

    // Cementerio con niebla adaptado a luz de luna. Si se borra este archivo,
    // se usa el fondo del menú principal como respaldo.
    static final BufferedImage FONDO_CEMENTERIO =
            primero("fondos/cementerio.png", "menu/fondo.png");

    // ===== Sprites del Acreedor (Vesper) =====
    static final BufferedImage SERIO = cargar("sprites/vesper-serio.png");
    static final BufferedImage SERIO_ABIERTO = cargar("sprites/vesper-serio-abierto.png");
    static final BufferedImage ENOJADO = cargar("sprites/vesper-enojado.png");
    static final BufferedImage ENOJADO_ABIERTO = cargar("sprites/vesper-enojado-abierto.png");
    static final BufferedImage CONTENTO_ABIERTO = cargar("sprites/vesper-contento-abierto.png");

    // No existe "vesper-contento.png": cuando está contento pero callado se usa
    // la cara seria, y cuando habla, la versión contenta con boca abierta.
    static final BufferedImage CONTENTO = SERIO;

    private ImagenesJuego(){}

    /** Devuelve la imagen de fondo correspondiente a la clave usada en el guion. */
    static BufferedImage fondo(String clave){
        if("habitacion".equals(clave)){
            return FONDO_HABITACION;
        }
        if("cementerio".equals(clave)){
            return FONDO_CEMENTERIO;
        }
        return null;
    }

    /**
     * Devuelve el sprite según la expresión y si el personaje está hablando.
     * "hablando = true" elige la variante con la boca abierta.
     */
    static BufferedImage sprite(String expresion, boolean hablando){
        if("enojado".equals(expresion)){
            return hablando ? ENOJADO_ABIERTO : ENOJADO;
        }
        if("contento".equals(expresion)){
            return hablando ? CONTENTO_ABIERTO : CONTENTO;
        }
        return hablando ? SERIO_ABIERTO : SERIO;
    }

    private static BufferedImage primero(String... rutas){
        for(String ruta : rutas){
            BufferedImage img = cargar(ruta);
            if(img != null) return img;
        }
        return null;
    }

    private static BufferedImage cargar(String rutaRelativa){

        try{
            File archivo = new File(RAIZ_RELATIVA + rutaRelativa);

            if(!archivo.exists()){
                archivo = new File(RAIZ_ABSOLUTA + rutaRelativa);
            }

            if(archivo.exists()){
                return ImageIO.read(archivo);
            }

        }catch(Exception ex){
            // Sin imagen: la escena se dibuja igual, con el fondo de respaldo.
        }

        return null;

    }

}
