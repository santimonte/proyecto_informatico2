import java.io.Serializable;

public class Guardado implements Serializable {

    private static final long serialVersionUID = 1L;

    private int escena;
    private String nombre;
    private String genero;
    private long fecha;
    private byte[] miniatura;

    public Guardado(int escena, String nombre, String genero) {

        this.escena = escena;
        this.nombre = nombre;
        this.genero = genero;
        this.fecha = System.currentTimeMillis();

    }

    public int getEscena() {
        return escena;
    }

    public void setEscena(int escena) {
        this.escena = escena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public long getFecha(){
        return fecha;
    }

    public byte[] getMiniatura(){
        return miniatura;
    }

    public void setMiniatura(byte[] miniatura){
        this.miniatura = miniatura;
    }

}