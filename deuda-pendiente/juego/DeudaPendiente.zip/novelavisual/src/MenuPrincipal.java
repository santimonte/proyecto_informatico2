import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.*;

public class MenuPrincipal extends JPanel implements MouseListener, MouseMotionListener {

    private Ventana ventana;

    private final String[] opciones = {"START","LOAD","SETTINGS","QUIT"};
    private List<Rectangle> botonesRects = new ArrayList<>();

    // Progreso de la animación de hover de cada ítem del menú (0 = normal,
    // 1 = resaltado del todo), para que el cambio sea un deslizamiento
    // suave y no un salto brusco de golpe.
    private final float[] hoverMenu = new float[opciones.length];

    private final EscaladoPantalla escalado = new EscaladoPantalla();

    private int mouseX = -1;
    private int mouseY = -1;

    // Reloj de la escena: todas las animaciones (cada niebla prendiéndose y
    // apagándose) se calculan a partir de cuánto tiempo pasó desde que se
    // abrió el menú, así siempre son fluidas sin importar la velocidad de
    // repintado.
    private final long inicioEscena = System.currentTimeMillis();
    private Timer animTimer;

    // Parpadeo sutil e irregular de toda la escena, como una vela que nunca
    // está del todo quieta. No es un ciclo prolijo como el de la niebla:
    // cada tanto elige un nuevo objetivo al azar y se acerca a él de a poco,
    // para que el resultado sea inquietante en vez de mecánico.
    private double parpadeo = 1.0;
    private double parpadeoObjetivo = 1.0;
    private int ticksParaProximoParpadeo = 0;
    private final java.util.Random rndParpadeo = new java.util.Random();

    public MenuPrincipal(Ventana ventana){

        this.ventana = ventana;

        setLayout(null);
        setBackground(Color.BLACK);
        setFocusable(true);

        addMouseListener(this);
        addMouseMotionListener(this);

        animTimer = new Timer(33, e -> {
            actualizarParpadeo();
            repaint();
        });
        animTimer.start();

        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    // Apaga el timer cuando este panel deja de estar visible, para no
    // dejarlo corriendo de fondo cuando cambiamos a otra pantalla.
    @Override
    public void removeNotify(){

        super.removeNotify();

        if(animTimer != null){
            animTimer.stop();
        }

    }

    private void actualizarParpadeo(){

        ticksParaProximoParpadeo--;

        if(ticksParaProximoParpadeo <= 0){

            // entre 0.88 (apenas se opaca) y 1.0 (brillo normal), nunca del todo oscuro
            parpadeoObjetivo = 0.88 + rndParpadeo.nextDouble() * 0.12;
            ticksParaProximoParpadeo = 12 + rndParpadeo.nextInt(45);

        }

        parpadeo += (parpadeoObjetivo - parpadeo) * 0.06;

    }

    @Override
    protected void paintComponent(Graphics g){

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        // Todo lo que sigue se dibuja sobre un lienzo virtual de 1280x720,
        // escalado y centrado para ocupar toda la ventana real (ventana o
        // pantalla completa), sin perder proporciones ni posiciones.
        escalado.actualizar(getWidth(), getHeight());
        escalado.aplicar(g2);

        long t = System.currentTimeMillis() - inicioEscena;

        dibujarEscena(g2, t);

        dibujarAmbiente(g2);
        dibujarVelo(g2);
        dibujarTitulo(g2);
        dibujarBotones(g2);

    }

    // Capas atmosféricas por encima de la escena: viñeta, filtro de color
    // frío/oscuro y el parpadeo irregular. Le dan un aire más tétrico y
    // misterioso sin tocar las imágenes originales.
    private void dibujarAmbiente(Graphics2D g2){

        int w = EscaladoPantalla.ANCHO_VIRTUAL;
        int h = EscaladoPantalla.ALTO_VIRTUAL;

        // Viñeta: oscurece las esquinas y bordes, dejando el centro despejado
        Point2D centro = new Point(w/2, (int)(h*0.55));
        float radio = w * 0.75f;

        RadialGradientPaint vinieta = new RadialGradientPaint(
                centro, radio,
                new float[]{0f, 0.62f, 1f},
                new Color[]{ new Color(0,0,0,0), new Color(0,0,0,60), new Color(0,0,0,175) }
        );

        Paint anterior = g2.getPaint();
        g2.setPaint(vinieta);
        g2.fillRect(0, 0, w, h);
        g2.setPaint(anterior);

        // Filtro de color frío y oscuro, muy sutil, para bajar el clima general
        g2.setColor(new Color(6,4,10,30));
        g2.fillRect(0, 0, w, h);

        // Parpadeo irregular: cuando "parpadeo" baja de 1.0, agrega una
        // sombra extra pareja sobre toda la escena, como si la luz ambiente
        // temblara un poco (nunca de forma mecánica ni previsible)
        int sombraExtra = (int)((1.0 - parpadeo) * 255 * 1.6);

        if(sombraExtra > 0){
            g2.setColor(new Color(0,0,0, Math.min(90, sombraExtra)));
            g2.fillRect(0, 0, w, h);
        }

    }

    // ================== Escena: fondo, personaje y niebla ==================

    private void dibujarEscena(Graphics2D g2, long t){

        // Fondo
        if(ImagenesMenu.FONDO != null){
            dibujarCapa(g2, ImagenesMenu.FONDO, 1f);
        } else {
            // Si todavía no pusiste las imágenes en la carpeta, usamos el
            // fondo de bosque dibujado a mano para que la pantalla no quede vacía
            Escenografia.dibujarBosque(g2, EscaladoPantalla.ANCHO_VIRTUAL, EscaladoPantalla.ALTO_VIRTUAL);
        }

        // Todas las capas de niebla se comportan igual: se prenden y apagan
        // en un ciclo continuo, siempre en degradé (nunca de golpe), cada
        // una con su propio ritmo y rango de opacidad para que no se vean
        // todas moviéndose exactamente igual al mismo tiempo.
        dibujarCapa(g2, ImagenesMenu.NIEBLA_TRASERA, respirar(t, 5200, 300, 0.20f, 0.55f));

        if(ImagenesMenu.ACREEDOR != null){
            dibujarCapa(g2, ImagenesMenu.ACREEDOR, 1f);
        }

        dibujarCapa(g2, ImagenesMenu.NIEBLA_OJOS_BOCA, respirar(t, 3200, 0, 0.06f, 0.9f));

        dibujarCapa(g2, ImagenesMenu.NIEBLA_BLANCA, respirar(t, 6000, 1800, 0.15f, 0.45f));

        dibujarCapa(g2, ImagenesMenu.NIEBLA_NEGRA, respirar(t, 7400, 900, 0.15f, 0.4f));

    }

    // Dibuja una imagen ocupando todo el lienzo virtual (las 6 imágenes
    // están preparadas al mismo tamaño y alineadas entre sí)
    private void dibujarCapa(Graphics2D g2, BufferedImage img, float alpha){

        if(img == null) return;

        Composite anterior = g2.getComposite();

        if(alpha < 1f){
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f, Math.min(1f, alpha))));
        }

        g2.drawImage(img, 0, 0, EscaladoPantalla.ANCHO_VIRTUAL, EscaladoPantalla.ALTO_VIRTUAL, null);

        g2.setComposite(anterior);

    }

    // Devuelve una opacidad que sube y baja suavemente en el tiempo (como
    // una respiración), usando una curva de coseno para que el cambio sea
    // siempre en degradé, sin saltos bruscos al prender o apagar.
    // "duracionCicloMs" = cuánto tarda un ciclo completo de encendido/apagado
    // "desfaseMs" = corre el punto de partida, para que las capas no
    // respiren todas exactamente sincronizadas entre sí.
    private float respirar(long tiempoMs, long duracionCicloMs, long desfaseMs, float alphaMin, float alphaMax){

        double fase = ((tiempoMs + desfaseMs) % duracionCicloMs) / (double) duracionCicloMs; // 0..1
        double onda = (1 - Math.cos(fase * Math.PI * 2)) / 2.0; // 0..1, suave

        return (float)(alphaMin + onda * (alphaMax - alphaMin));

    }

    private void dibujarVelo(Graphics2D g2){

        // Velo oscuro y muy sutil detrás del título y el menú, para que el
        // texto siempre se lea bien sin importar qué tan clara esté la
        // niebla en ese momento. Uso un degradé RADIAL (no un rectángulo)
        // para que se apague de a poco en TODAS direcciones, sin ningún
        // borde duro que corte a la niebla que pasa por detrás.
        Point2D centro = new Point(40, 170);
        float radio = 620f;

        RadialGradientPaint velo = new RadialGradientPaint(
                centro, radio,
                new float[]{0f, 1f},
                new Color[]{ new Color(0,0,0,140), new Color(0,0,0,0) }
        );

        Paint anterior = g2.getPaint();
        g2.setPaint(velo);
        g2.fillRect(0, 0, EscaladoPantalla.ANCHO_VIRTUAL, EscaladoPantalla.ALTO_VIRTUAL);
        g2.setPaint(anterior);

    }

    private void dibujarTitulo(Graphics2D g2){

        int x = 72;

        g2.setFont(Fuentes.gotica(58f));

        int alfaTitulo = (int)(255 * (0.75 + 0.25 * parpadeo));

        g2.setColor(new Color(0,0,0,190));
        g2.drawString("DEUDA", x + 3, 108 + 3);
        g2.drawString("PENDIENTE", x + 3, 172 + 3);

        g2.setColor(new Color(240,233,218, Math.min(255, alfaTitulo)));
        g2.drawString("DEUDA", x, 108);
        g2.drawString("PENDIENTE", x, 172);

        // línea debajo del título, en un degradé dorado que se apaga hacia la derecha
        FontMetrics fm = g2.getFontMetrics();
        int anchoLinea = Math.max(fm.stringWidth("DEUDA"), fm.stringWidth("PENDIENTE"));

        LinearGradientPaint lineaDorada = new LinearGradientPaint(
                new Point(x, 192), new Point(x + anchoLinea, 192),
                new float[]{0f, 1f},
                new Color[]{ new Color(214,178,110,220), new Color(214,178,110,0) }
        );

        Paint anterior = g2.getPaint();
        g2.setPaint(lineaDorada);
        g2.setStroke(new BasicStroke(2f));
        g2.drawLine(x, 192, x + anchoLinea, 192);
        g2.setPaint(anterior);

    }

    // ================== Botones ==================

    private void dibujarBotones(Graphics2D g2){

        botonesRects.clear();

        int x = 72;
        int y = 258;
        int alturaItem = 46;

        for(int i = 0; i < opciones.length; i++){

            Rectangle r = new Rectangle(x - 30, y - 26, 280, alturaItem);

            botonesRects.add(r);

            boolean hover = r.contains(new Point(mouseX, mouseY));

            // Suaviza el paso a "resaltado" y viceversa en vez de cambiar de golpe
            float objetivo = hover ? 1f : 0f;
            hoverMenu[i] += (objetivo - hoverMenu[i]) * 0.22f;

            if(Math.abs(objetivo - hoverMenu[i]) < 0.004f){
                hoverMenu[i] = objetivo;
            }

            dibujarItemMenu(g2, x, y, traducir(opciones[i]).toUpperCase(), hoverMenu[i]);

            y += alturaItem;

        }

    }

    private void dibujarItemMenu(Graphics2D g2, int x, int y, String texto, float progreso){

        int desplazamiento = (int)(progreso * 16);

        // Rombito dorado que se desliza y aparece en degradé a la izquierda del texto
        if(progreso > 0.02f){

            int alfa = (int)(progreso * 255);
            int cx = x - 20 + desplazamiento;
            int cy = y - 8;
            int s = 5;

            Polygon rombo = new Polygon();
            rombo.addPoint(cx, cy - s);
            rombo.addPoint(cx + s, cy);
            rombo.addPoint(cx, cy + s);
            rombo.addPoint(cx - s, cy);

            g2.setColor(new Color(214,178,110, alfa));
            g2.fillPolygon(rombo);

        }

        Color colorNormal = new Color(150,145,140);
        Color colorResaltado = new Color(238,222,190);

        int rr = (int)(colorNormal.getRed()   + (colorResaltado.getRed()   - colorNormal.getRed())   * progreso);
        int gg = (int)(colorNormal.getGreen() + (colorResaltado.getGreen() - colorNormal.getGreen()) * progreso);
        int bb = (int)(colorNormal.getBlue()  + (colorResaltado.getBlue()  - colorNormal.getBlue())  * progreso);

        g2.setFont(Fuentes.gotica(24f));

        int tx = x + desplazamiento;

        // Resplandor rojizo detrás del texto cuando está resaltado, como
        // una brasa: le da un aire más inquietante que un simple hover blanco
        if(progreso > 0.05f){

            int alfaResplandor = (int)(progreso * 110);
            g2.setColor(new Color(150,20,20, alfaResplandor));

            for(int dx = -1; dx <= 1; dx++){
                for(int dy = -1; dy <= 1; dy++){
                    if(dx != 0 || dy != 0){
                        g2.drawString(texto, tx + dx, y + dy);
                    }
                }
            }

        }

        g2.setColor(new Color(0,0,0, 150));
        g2.drawString(texto, tx + 1, y + 1);

        g2.setColor(new Color(rr, gg, bb));
        g2.drawString(texto, tx, y);

    }

    private String traducir(String opcion){

        switch(opcion){
            case "START": return "Comenzar";
            case "LOAD": return "Cargar partida";
            case "SETTINGS": return "Ajustes";
            case "QUIT": return "Salir";
            default: return opcion;
        }

    }

    // ================== Interacción ==================

    @Override
    public void mousePressed(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        for(int i = 0; i < botonesRects.size(); i++){

            if(botonesRects.get(i).contains(p)){

                accion(opciones[i]);

                return;

            }

        }

    }

    private void accion(String opcion){

        switch(opcion){

            case "START":

                ventana.cambiar(new JuegoPanel(ventana));
                ventana.revalidate();
                ventana.repaint();

                break;

            case "LOAD":

                ventana.cambiar(new SavePanel(ventana, null, false));

                break;

            case "SETTINGS":

                ventana.cambiar(new AjustesPanel(ventana));

                break;

            case "QUIT":

                System.exit(0);
                break;
        }
    }

    @Override
    public void mouseMoved(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        mouseX = p.x;
        mouseY = p.y;

        repaint();

    }

    @Override
    public void mouseDragged(MouseEvent e){}

    @Override
    public void mouseClicked(MouseEvent e){}

    @Override
    public void mouseReleased(MouseEvent e){}

    @Override
    public void mouseEntered(MouseEvent e){}

    @Override
    public void mouseExited(MouseEvent e){}

}

// ===================================================================
// A partir de acá van dos clases de apoyo, metidas en el mismo archivo
// para que sea todo un solo .java (no pueden ser "public": Java solo
// permite una clase pública por archivo, y esa es MenuPrincipal de arriba).
// ===================================================================

// Todas las pantallas del juego se diseñaron pensando en un lienzo fijo de
// 1280x720. En vez de recalcular cada posición según el tamaño real de la
// ventana (que cambia entre modo ventana y pantalla completa, y entre
// distintas resoluciones de pantalla), dibujamos siempre sobre ese lienzo
// virtual de 1280x720 y lo escalamos/centramos para que ocupe la ventana
// real, sea cual sea su tamaño.
class EscaladoPantalla {

    static final int ANCHO_VIRTUAL = 1280;
    static final int ALTO_VIRTUAL = 720;

    private double escala = 1.0;
    private int offsetX = 0;
    private int offsetY = 0;

    // Recalcula la escala y el desplazamiento necesarios para centrar el
    // lienzo virtual dentro de un área real de "anchoReal" x "altoReal".
    void actualizar(int anchoReal, int altoReal){

        if(anchoReal <= 0 || altoReal <= 0){
            escala = 1.0;
            offsetX = 0;
            offsetY = 0;
            return;
        }

        double escalaX = anchoReal / (double) ANCHO_VIRTUAL;
        double escalaY = altoReal / (double) ALTO_VIRTUAL;

        escala = Math.min(escalaX, escalaY);

        offsetX = (int) Math.round((anchoReal - ANCHO_VIRTUAL * escala) / 2.0);
        offsetY = (int) Math.round((altoReal - ALTO_VIRTUAL * escala) / 2.0);

    }

    // Aplica la transformación al contexto gráfico: a partir de acá, todo lo
    // que se dibuje puede usar coordenadas del lienzo virtual (0..1280, 0..720).
    void aplicar(Graphics2D g2){
        g2.translate(offsetX, offsetY);
        g2.scale(escala, escala);
    }

    // Convierte una coordenada real del mouse (la que llega en un MouseEvent)
    // a la coordenada equivalente dentro del lienzo virtual.
    Point aVirtual(int xReal, int yReal){

        double e = (escala == 0) ? 1.0 : escala;

        return new Point(
                (int) Math.round((xReal - offsetX) / e),
                (int) Math.round((yReal - offsetY) / e)
        );

    }

}

// Carga las imágenes de la escena del menú principal (fondo, personaje y
// las distintas capas de niebla) una sola vez y las deja disponibles para
// todo el juego. Si algún archivo no está en la carpeta, esa imagen queda
// en null y las pantallas que la usan simplemente no la dibujan, en vez de
// romper el juego.
class ImagenesMenu {

    // Carpeta donde vas a poner los 6 archivos .png (fondo, acreedor y las
    // 4 niebla). Si movés el proyecto, actualizá esta ruta.
    private static final String CARPETA = "C:\\Users\\choco\\Desktop\\novelavisual\\assets\\menu\\";

    static final BufferedImage FONDO = cargar("fondo.png");
    static final BufferedImage ACREEDOR = cargar("acreedor.png");
    static final BufferedImage NIEBLA_TRASERA = cargar("NieblaTrasera.png");
    static final BufferedImage NIEBLA_BLANCA = cargar("NieblaBlanca.png");
    static final BufferedImage NIEBLA_NEGRA = cargar("NieblaNegra.png");
    static final BufferedImage NIEBLA_OJOS_BOCA = cargar("NiebladeOjosYboca.png");

    private ImagenesMenu(){}

    private static BufferedImage cargar(String nombreArchivo){

        try{

            File archivo = new File(CARPETA + nombreArchivo);

            if(archivo.exists()){
                return ImageIO.read(archivo);
            }

        }catch(Exception ex){
            // Si falla la carga, seguimos sin esa imagen en vez de tirar abajo el juego
        }

        return null;

    }

}
