import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.*;

// Panel de Guardar/Cargar partida, con el layout típico de Ren'Py:
// barra lateral de navegación a la izquierda + grilla de slots con
// miniatura y fecha a la derecha.
//
// - Si modoGuardar == true: guarda el estado de "juego" en el slot elegido.
//   (juego NO puede ser null en este modo)
// - Si modoGuardar == false: carga el slot elegido. Si "juego" es null
//   (viniendo del menú principal), crea una partida nueva para cargar.
public class SavePanel extends JPanel implements MouseListener, MouseMotionListener {

    private static final int SIDEBAR_ANCHO = 300;

    private Ventana ventana;
    private JuegoPanel juego;
    private boolean modoGuardar;

    private List<String> itemsNav = new ArrayList<>();
    private List<Rectangle> navRects = new ArrayList<>();
    private Rectangle volverRect;

    private List<Rectangle> slotRects = new ArrayList<>();

    // Cache de los datos de cada slot: se lee el disco una sola vez al abrir
    // esta pantalla, no en cada repintado (el hover repinta muy seguido).
    private Guardado[] guardadosCache;
    private BufferedImage[] miniaturasCache;

    private int mouseX = -1;
    private int mouseY = -1;

    private final EscaladoPantalla escalado = new EscaladoPantalla();

    private final SimpleDateFormat formatoFecha =
            new SimpleDateFormat("EEEE, d 'de' MMMM yyyy, HH:mm", new Locale("es","ES"));

    public SavePanel(Ventana ventana, JuegoPanel juego, boolean modoGuardar) {

        this.ventana = ventana;
        this.juego = juego;
        this.modoGuardar = modoGuardar;

        setLayout(null);
        setBackground(Color.BLACK);
        setFocusable(true);

        addMouseListener(this);
        addMouseMotionListener(this);

        itemsNav.add(juego != null ? "Continuar" : "Comenzar");

        if(juego != null){
            itemsNav.add("Guardar");
        }

        itemsNav.add("Cargar");
        itemsNav.add("Ajustes");

        if(juego != null){
            itemsNav.add("Menú Principal");
        }

        itemsNav.add("Salir");

        cargarDatosSlots();

        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    private void cargarDatosSlots(){

        guardadosCache = new Guardado[SaveManager.SLOTS];
        miniaturasCache = new BufferedImage[SaveManager.SLOTS];

        for(int i = 1; i <= SaveManager.SLOTS; i++){

            if(!SaveManager.existe(i)) continue;

            Guardado g = SaveManager.cargar(i);

            guardadosCache[i-1] = g;

            if(g != null && g.getMiniatura() != null){

                try{
                    miniaturasCache[i-1] = ImageIO.read(new ByteArrayInputStream(g.getMiniatura()));
                }catch(Exception ex){
                    miniaturasCache[i-1] = null;
                }

            }

        }

    }

    @Override
    protected void paintComponent(Graphics g){

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        escalado.actualizar(getWidth(), getHeight());
        escalado.aplicar(g2);

        Escenografia.dibujarBosque(g2, EscaladoPantalla.ANCHO_VIRTUAL, EscaladoPantalla.ALTO_VIRTUAL);

        // Barra lateral
        g2.setColor(new Color(0,0,0,235));
        g2.fillRect(0, 0, SIDEBAR_ANCHO, EscaladoPantalla.ALTO_VIRTUAL);

        dibujarTitulo(g2);
        dibujarNav(g2);
        dibujarVolver(g2);

        dibujarSlots(g2);

    }

    // ================== Barra lateral ==================

    private void dibujarTitulo(Graphics2D g2){

        String titulo = modoGuardar ? "Guardar" : "Cargar";

        g2.setFont(Fuentes.gotica(44f));
        g2.setColor(new Color(195,30,30));
        g2.drawString(titulo, 32, 110);

    }

    private void dibujarNav(Graphics2D g2){

        navRects.clear();

        int x = 32;
        int y = 210;
        int alturaItem = 44;

        for(String item : itemsNav){

            Rectangle r = new Rectangle(x, y - 28, SIDEBAR_ANCHO - 64, alturaItem);

            navRects.add(r);

            boolean actual = esItemActual(item);
            boolean hover = r.contains(new Point(mouseX, mouseY));

            g2.setFont(new Font("Arial", actual ? Font.BOLD : Font.PLAIN, actual ? 23 : 21));

            if(actual){
                g2.setColor(Color.WHITE);
            } else {
                g2.setColor(hover ? Color.WHITE : new Color(150,150,150));
            }

            g2.drawString(item, x, y);

            y += alturaItem;

        }

    }

    private boolean esItemActual(String item){

        if(item.equals("Guardar")) return modoGuardar;
        if(item.equals("Cargar")) return !modoGuardar;

        return false;

    }

    private void dibujarVolver(Graphics2D g2){

        int x = 32;
        int y = EscaladoPantalla.ALTO_VIRTUAL - 50;

        volverRect = new Rectangle(x, y - 28, 150, 40);

        boolean hover = volverRect.contains(new Point(mouseX, mouseY));

        g2.setFont(new Font("Arial", Font.PLAIN, 21));
        g2.setColor(hover ? Color.WHITE : new Color(160,160,160));
        g2.drawString("Volver", x, y);

    }

    // ================== Slots ==================

    private void dibujarSlots(Graphics2D g2){

        slotRects.clear();

        int cardWidth = 280;
        int cardHeight = 158;
        int gap = 40;

        int totalWidth = SaveManager.SLOTS * cardWidth + (SaveManager.SLOTS - 1) * gap;

        int areaX = SIDEBAR_ANCHO;
        int areaAncho = EscaladoPantalla.ANCHO_VIRTUAL - SIDEBAR_ANCHO;

        int startX = areaX + Math.max(20, (areaAncho - totalWidth) / 2);
        int y = 270;

        for(int i = 1; i <= SaveManager.SLOTS; i++){

            int x = startX + (i - 1) * (cardWidth + gap);

            Rectangle r = new Rectangle(x, y, cardWidth, cardHeight);
            slotRects.add(r);

            dibujarCarta(g2, r, i);

        }

    }

    private void dibujarCarta(Graphics2D g2, Rectangle r, int slot){

        boolean existe = SaveManager.existe(slot);
        boolean hover = r.contains(new Point(mouseX, mouseY));

        Guardado g = guardadosCache[slot-1];
        BufferedImage miniatura = miniaturasCache[slot-1];

        if(miniatura != null){
            g2.drawImage(miniatura, r.x, r.y, r.width, r.height, null);
        } else {
            dibujarPlaceholder(g2, r, existe ? ("Slot " + slot) : "Vacío");
        }

        // borde de la carta, se resalta al pasar el mouse
        g2.setStroke(new BasicStroke(hover ? 3f : 1.5f));
        g2.setColor(hover ? new Color(210,40,40) : new Color(255,255,255,70));
        g2.drawRect(r.x, r.y, r.width, r.height);
        g2.setStroke(new BasicStroke(1f));

        // barra roja de resaltado al pasar el mouse (como en el ejemplo de Ren'Py)
        if(hover){
            g2.setColor(new Color(210,40,40));
            g2.fillRect(r.x - 5, r.y, 5, r.height);
        }

        // etiqueta con la fecha (o "vacío"), debajo de la carta
        String etiqueta = (g != null)
                ? capitalizar(formatoFecha.format(new Date(g.getFecha())))
                : "Slot " + slot + " — vacío";

        g2.setFont(new Font("Arial", Font.PLAIN, 15));

        FontMetrics fm = g2.getFontMetrics();
        int tx = r.x + (r.width - fm.stringWidth(etiqueta)) / 2;
        int ty = r.y + r.height + 24;

        g2.setColor(hover ? new Color(230,70,70) : new Color(205,205,205));
        g2.drawString(etiqueta, tx, ty);

    }

    private void dibujarPlaceholder(Graphics2D g2, Rectangle r, String texto){

        g2.setColor(new Color(24,21,19));
        g2.fillRect(r.x, r.y, r.width, r.height);

        g2.setFont(new Font("Arial", Font.PLAIN, 18));
        FontMetrics fm = g2.getFontMetrics();

        g2.setColor(new Color(120,110,100));
        g2.drawString(texto, r.x + (r.width - fm.stringWidth(texto)) / 2, r.y + r.height / 2 + 6);

    }

    private String capitalizar(String s){

        if(s == null || s.isEmpty()) return s;

        return Character.toUpperCase(s.charAt(0)) + s.substring(1);

    }

    //Interacción

    @Override
    public void mousePressed(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        for(int i = 0; i < slotRects.size(); i++){

            if(slotRects.get(i).contains(p)){

                int slot = i + 1;

                manejarSlot(slot, SaveManager.existe(slot));

                return;

            }

        }

        for(int i = 0; i < navRects.size(); i++){

            if(navRects.get(i).contains(p)){

                manejarNav(itemsNav.get(i));

                return;

            }

        }

        if(volverRect != null && volverRect.contains(p)){

            volver();

        }

    }

    private void manejarNav(String item){

        switch(item){

            case "Comenzar":

                ventana.cambiar(new JuegoPanel(ventana));
                ventana.revalidate();
                ventana.repaint();

                break;

            case "Continuar":

                ventana.cambiar(juego);

                break;

            case "Guardar":

                if(!modoGuardar){
                    ventana.cambiar(new SavePanel(ventana, juego, true));
                }

                break;

            case "Cargar":

                if(modoGuardar){
                    ventana.cambiar(new SavePanel(ventana, juego, false));
                }

                break;

            case "Ajustes":

                ventana.cambiar(new AjustesPanel(ventana));

                break;

            case "Menú Principal":

                ventana.cambiar(new MenuPrincipal(ventana));

                break;

            case "Salir":

                System.exit(0);
                break;

        }

    }

    private void volver(){

        if(juego != null){
            ventana.cambiar(juego);
        } else {
            ventana.cambiar(new MenuPrincipal(ventana));
        }

    }

    private void manejarSlot(int slot, boolean existe) {

        if (modoGuardar) {

            Guardado g = juego.crearGuardado();

            SaveManager.guardar(g, slot);

            JOptionPane.showMessageDialog(this, "¡Partida guardada!");

            ventana.cambiar(juego);

        } else {

            if (!existe) {
                JOptionPane.showMessageDialog(this, "Ese slot está vacío.");
                return;
            }

            Guardado g = SaveManager.cargar(slot);

            if (g == null) {
                JOptionPane.showMessageDialog(this, "No se pudo leer la partida.");
                return;
            }

            JuegoPanel nuevoJuego = new JuegoPanel(ventana);
            nuevoJuego.cargarPartida(g);

            ventana.cambiar(nuevoJuego);

        }

    }

    @Override
    public void mouseMoved(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        mouseX = p.x;
        mouseY = p.y;

        repaint();

    }

    @Override
    public void mouseDragged(MouseEvent e){}

    @Override
    public void mouseClicked(MouseEvent e){}

    @Override
    public void mouseReleased(MouseEvent e){}

    @Override
    public void mouseEntered(MouseEvent e){}

    @Override
    public void mouseExited(MouseEvent e){}

}