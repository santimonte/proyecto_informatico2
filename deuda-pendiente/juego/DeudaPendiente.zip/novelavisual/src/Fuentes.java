import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

// Carga la fuente gótica una sola vez y la comparte entre todas las pantallas.
public class Fuentes {

    private Fuentes(){}

    private static final Font GOTICA_BASE = cargarFuenteGotica();

    public static Font gotica(float tamaño){
        return GOTICA_BASE.deriveFont(tamaño);
    }

    private static Font cargarFuenteGotica(){

        // 1) Si en la carpeta "recursos" hay un archivo fuente_gotica.ttf, usarlo
        //    (por ejemplo, "UnifrakturMaguntia" o "Pirata One" de Google Fonts)
        try{

            File archivo = new File("recursos/fuente_gotica.ttf");

            if(archivo.exists()){
                return Font.createFont(Font.TRUETYPE_FONT, archivo).deriveFont(40f);
            }

        }catch(Exception ex){
            // si falla la carga, seguimos con las alternativas de abajo
        }

        // 2) Si el sistema operativo tiene instalada alguna fuente gótica/medieval
        String[] candidatas = {
                "UnifrakturMaguntia", "UnifrakturCook", "Old English Text MT",
                "Blackadder ITC", "MedievalSharp", "Pirata One",
                "Cinzel Decorative", "Monotype Corsiva", "Chiller", "Herculanum"
        };

        Set<String> disponibles = new HashSet<>(Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()
        ));

        for(String nombre : candidatas){

            if(disponibles.contains(nombre)){
                return new Font(nombre, Font.PLAIN, 40);
            }

        }

        // 3) Alternativa segura, siempre disponible
        return new Font("Serif", Font.BOLD | Font.ITALIC, 40);

    }

}
