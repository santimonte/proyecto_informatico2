import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import javax.swing.*;

public class Ventana extends JFrame {

    private static final int ANCHO_VENTANA = 1280;
    private static final int ALTO_VENTANA = 720;

    private final GraphicsDevice dispositivo;

    public Ventana() {

        dispositivo = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();

        setTitle("Deuda Pendiente");
        setSize(ANCHO_VENTANA, ALTO_VENTANA);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(true);

        setContentPane(new MenuPrincipal(this));

        if(Configuracion.pantallaCompleta){
            activarPantallaCompleta();
        } else {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setVisible(true);
        }

    }

    public void cambiar(JPanel p){
        setContentPane(p);
        revalidate();
        repaint();
    }

    // Cambia entre modo ventana y pantalla completa, conservando el panel
    // que esté actualmente en pantalla.
    public void setPantallaCompleta(boolean completa){

        if(completa == Configuracion.pantallaCompleta) return;

        Configuracion.pantallaCompleta = completa;

        if(completa){
            activarPantallaCompleta();
        } else {
            desactivarPantallaCompleta();
        }

    }

    public boolean isPantallaCompleta(){
        return Configuracion.pantallaCompleta;
    }

    private void activarPantallaCompleta(){

        JPanel panelActual = (JPanel) getContentPane();

        dispose();
        setUndecorated(true);
        setResizable(false);

        if(dispositivo.isFullScreenSupported()){
            dispositivo.setFullScreenWindow(this);
        } else {
            // Si el sistema no soporta pantalla completa exclusiva,
            // maximizamos la ventana como alternativa
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setVisible(true);
        }

        setContentPane(panelActual);
        revalidate();
        repaint();

    }

    // Modo "ventana" que ocupa toda la pantalla disponible (maximizada),
    // pero conserva la barra de título y los bordes de una ventana normal
    // (a diferencia de la pantalla completa, que es exclusiva y sin bordes).
    private void desactivarPantallaCompleta(){

        JPanel panelActual = (JPanel) getContentPane();

        if(dispositivo.getFullScreenWindow() == this){
            dispositivo.setFullScreenWindow(null);
        }

        dispose();
        setUndecorated(false);
        setResizable(true);

        setContentPane(panelActual);

        // Tamaño de respaldo por si el sistema no soporta maximizar
        setSize(ANCHO_VENTANA, ALTO_VENTANA);
        setLocationRelativeTo(null);

        setVisible(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        revalidate();
        repaint();

    }
}