import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Escena {

    private String personaje;
    private String texto;
    private String genero = "";

    // Opciones de elección (si la escena tiene ramas)
    private String[] opciones;
    private int[] destinos;

    // Marca si esta escena es un final del capítulo
    private boolean esFinal = false;

    // Patrón para pares de palabras completas separadas por "|", escrito
    // como {masculino|femenino}. Se usa cuando las dos formas no comparten
    // la misma raíz (por ejemplo "el"/"la", o "lo"/"la"), a diferencia del
    // comodín "@" que solo sirve para cambiar la última vocal de una palabra.
    private static final Pattern PATRON_PAR_GENERO = Pattern.compile("\\{([^{}|]+)\\|([^{}|]+)\\}");

    public Escena(String personaje, String texto){
        this.personaje = personaje;
        this.texto = texto;
    }

    public String getPersonaje(){
        return personaje;
    }

    public String getTexto(){
        return texto;
    }

    public void setPersonaje(String p){
        this.personaje = p;
    }

    public void setGenero(String genero){
        this.genero = genero;
    }

    public String getGenero(){
        return genero;
    }

    //Opciones / elecciones

    public void setOpciones(String[] opciones, int[] destinos){
        this.opciones = opciones;
        this.destinos = destinos;
    }

    public String[] getOpciones(){
        return opciones;
    }

    public int[] getDestinos(){
        return destinos;
    }

    public boolean tieneOpciones(){
        return opciones != null && opciones.length > 0;
    }

    //Finales

    public void setEsFinal(boolean esFinal){
        this.esFinal = esFinal;
    }

    public boolean isEsFinal(){
        return esFinal;
    }

    // Reemplaza {nombre} y también cualquier aparición suelta de "T/N"
    // (el placeholder que usa el guión para referirse al/a la protagonista,
    // tanto como nombre de personaje que habla como dentro de la narración
    // en tercera persona) por el nombre real que eligió el jugador.
    public void aplicarNombre(String nombre){

        if(nombre == null) return;

        if(texto != null){
            texto = texto.replace("{nombre}", nombre);
            texto = texto.replace("T/N", nombre);
        }

        if(personaje != null){

            personaje = personaje.replace("{nombre}", nombre);

            if(personaje.equals("T/N")){
                personaje = nombre;
            } else {
                personaje = personaje.replace("T/N", nombre);
            }

        }

    }

    // Aplica el género elegido en dos formas:
    // 1) El comodín "@" (ej: "cansad@", "sol@") se reemplaza por la
    //    terminación correspondiente (o/a/e).
    // 2) Los pares de palabras completas {masculino|femenino} (ej:
    //    "{el|la}", "{lo|la}") se resuelven eligiendo la palabra que
    //    corresponda. Para "Otro" no hay una tercera palabra natural para
    //    estos pronombres, así que se usa la forma masculina como base.
    public void aplicarGenero(String genero){

        if(genero == null) return;

        this.genero = genero;

        String terminacion;

        switch(genero){

            case "Masculino":
                terminacion = "o";
                break;

            case "Femenino":
                terminacion = "a";
                break;

            default:
                terminacion = "e";
                break;

        }

        boolean usarFemenino = "Femenino".equals(genero);

        if(texto != null){
            texto = texto.replace("@", terminacion);
            texto = resolverParesGenero(texto, usarFemenino);
        }

        if(personaje != null){
            personaje = personaje.replace("@", terminacion);
            personaje = resolverParesGenero(personaje, usarFemenino);
        }

    }

    private String resolverParesGenero(String s, boolean usarFemenino){

        Matcher m = PATRON_PAR_GENERO.matcher(s);
        StringBuffer resultado = new StringBuffer();

        while(m.find()){

            String masculino = m.group(1);
            String femenino = m.group(2);

            String elegido = usarFemenino ? femenino : masculino;

            m.appendReplacement(resultado, Matcher.quoteReplacement(elegido));

        }

        m.appendTail(resultado);

        return resultado.toString();

    }

}
