import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;

public class JuegoPanel extends JPanel implements MouseListener, MouseMotionListener, MouseWheelListener, KeyListener {

    private Ventana ventana;
    private GestorEscenas gestor;

    // Estados
    // 0 = escribir nombre
    // 1 = elegir género
    // 2 = historia
    private int estado = 0;

    private String nombre = "";
    private String genero = "";

    // Máquina de escribir
    private String textoMostrado = "";
    private int indiceTexto = 0;
    private Timer timerTexto;

    // Auto (avanza solo cuando termina de escribir una línea) y Skip (avanza rápido y sin animación)
    private boolean autoPlay = false;
    private boolean modoSkip = false;
    private Timer autoAdvanceTimer;
    private Timer skipTimer;

    // Historial de diálogos ya vistos
    private final ArrayList<String[]> historial = new ArrayList<>(); // {personaje, texto}
    private boolean mostrandoHistorial = false;
    private int scrollHistorial = 0;

    // UI
    private Rectangle botonMasculino =
            new Rectangle(80,570,170,45);

    private Rectangle botonFemenino =
            new Rectangle(260,570,170,45);

    private Rectangle botonOtro =
            new Rectangle(440,570,170,45);

    private Rectangle guardar;
    private Rectangle cargar;
    private Rectangle autoRect;
    private Rectangle skipRect;
    private Rectangle historialRect;

    // Botones de opciones (elecciones), se recalculan cada vez que se muestran
    private java.util.List<Rectangle> opcionesRects = new java.util.ArrayList<>();

    // Posición del mouse, usada para el efecto hover del quick menu (estilo Ren'Py)
    private int mouseX = -1;
    private int mouseY = -1;

    private final EscaladoPantalla escalado = new EscaladoPantalla();

    public JuegoPanel(Ventana ventana){

        this.ventana = ventana;

        gestor = new GestorEscenas();

        setLayout(null);
        setFocusable(true);

        addMouseListener(this);
        addMouseMotionListener(this);
        addMouseWheelListener(this);
        addKeyListener(this);

        timerTexto = new Timer(Configuracion.velocidadTexto, e -> {

            String texto = gestor.getEscena().getTexto();

            if(indiceTexto < texto.length()){

                textoMostrado += texto.charAt(indiceTexto);
                indiceTexto++;

                repaint();

            }else{

                timerTexto.stop();
                manejarFinDeTexto();

            }

        });

        autoAdvanceTimer = new Timer(1400, e -> avanzarSiCorresponde());
        autoAdvanceTimer.setRepeats(false);

        skipTimer = new Timer(140, e -> avanzarSiCorresponde());
        skipTimer.setRepeats(false);

        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    private void comenzarTexto(){

        textoMostrado = "";
        indiceTexto = 0;

        if(modoSkip){

            // En modo Skip el texto aparece completo al instante
            String texto = gestor.getEscena().getTexto();

            textoMostrado = texto;
            indiceTexto = texto.length();

            timerTexto.stop();

            manejarFinDeTexto();

        } else {

            timerTexto.restart();

        }

    }

    // Se ejecuta apenas una línea terminó de escribirse (a mano o de golpe por Skip).
    // Decide si hay que parar (opciones / final) o encadenar el próximo avance
    // automático según el modo Auto o Skip.
    private void manejarFinDeTexto(){

        if(gestor.tieneOpciones() || gestor.esFinal()){

            // Como en Ren'Py: Skip se detiene solo al llegar a una elección o a un final
            modoSkip = false;

            repaint();

            return;

        }

        if(modoSkip){

            skipTimer.restart();

        } else if(autoPlay){

            autoAdvanceTimer.restart();

        }

    }

    // Usado por los timers de Auto y Skip para avanzar la escena sin intervención del mouse
    private void avanzarSiCorresponde(){

        if(estado != 2 || mostrandoHistorial) return;

        Escena escenaActual = gestor.getEscena();

        boolean textoCompleto = indiceTexto >= escenaActual.getTexto().length();

        if(!textoCompleto) return;
        if(gestor.tieneOpciones() || gestor.esFinal()) return;

        registrarHistorial();
        siguienteEscena();

    }

    private void registrarHistorial(){

        Escena e = gestor.getEscena();

        if(e != null){
            historial.add(new String[]{ e.getPersonaje(), e.getTexto() });
        }

    }

    private void detenerAutoYSkip(){

        autoAdvanceTimer.stop();
        skipTimer.stop();

    }

    private void siguienteEscena(){

        gestor.siguiente();
        comenzarTexto();

    }

    private void iniciarJuego(){

        gestor.aplicarNombre(nombre);
        gestor.aplicarGenero(genero);

        estado = 2;

        comenzarTexto();

        repaint();

    }

    public Guardado crearGuardado(){

        Guardado g = new Guardado(gestor.getIndex(), nombre, genero);

        g.setMiniatura(capturarMiniatura());

        return g;

    }

    // Renderiza este mismo panel a una imagen chica en memoria (PNG),
    // para mostrarla como miniatura en la pantalla de Cargar partida.
    private byte[] capturarMiniatura(){

        try{

            int anchoMini = 300;
            int altoMini = 169;

            BufferedImage completa = new BufferedImage(
                    Math.max(1, getWidth()), Math.max(1, getHeight()), BufferedImage.TYPE_INT_RGB
            );

            Graphics2D g2completa = completa.createGraphics();
            paint(g2completa);
            g2completa.dispose();

            BufferedImage mini = new BufferedImage(anchoMini, altoMini, BufferedImage.TYPE_INT_RGB);

            Graphics2D g2mini = mini.createGraphics();
            g2mini.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2mini.drawImage(completa, 0, 0, anchoMini, altoMini, null);
            g2mini.dispose();

            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            ImageIO.write(mini, "png", salida);

            return salida.toByteArray();

        }catch(Exception ex){

            return null;

        }

    }

    public void cargarPartida(Guardado g){

        nombre = g.getNombre();
        genero = g.getGenero();
        estado = 2;

        gestor.aplicarNombre(nombre);
        gestor.aplicarGenero(genero);
        gestor.setIndex(g.getEscena());

        comenzarTexto();

        repaint();

        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    // Geometría de la caja de diálogo (estilo Ren'Py: ancha y pegada abajo)
    private static final int CAJA_X = 20;
    private static final int CAJA_ALTO = 165;
    private static final int CAJA_MARGEN_INFERIOR = 55;

    @Override
    protected void paintComponent(Graphics g){

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(55,55,55));
        g2.fillRect(0,0,getWidth(),getHeight());

        // A partir de acá dibujamos sobre un lienzo virtual de 1280x720,
        // escalado y centrado para ocupar toda la ventana real (ventana o
        // pantalla completa), sin perder proporciones ni posiciones.
        escalado.actualizar(getWidth(), getHeight());
        escalado.aplicar(g2);

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial",Font.PLAIN,24));

        if(estado == 0){

            g2.setColor(new Color(15,15,15,220));
            g2.fillRoundRect(40,470,1200,210,20,20);

            g2.setColor(Color.WHITE);
            g2.drawString("¿Cómo te llamás?",80,530);

            g2.drawString("> " + nombre + "_",80,580);

        }

        else if(estado == 1){

            g2.setColor(new Color(15,15,15,220));
            g2.fillRoundRect(40,470,1200,210,20,20);

            g2.setColor(Color.WHITE);
            g2.drawString("Elegí tu género",80,530);

            dibujarBotonGenero(g2,botonMasculino,"Masculino");
            dibujarBotonGenero(g2,botonFemenino,"Femenino");
            dibujarBotonGenero(g2,botonOtro,"Otro");

        }

        else{

            if(mostrandoHistorial){

                dibujarHistorial(g2);

            } else {

                Escena escena = gestor.getEscena();

                boolean textoCompleto = indiceTexto >= escena.getTexto().length();
                boolean mostrandoOpciones = textoCompleto && gestor.tieneOpciones();

                if(!mostrandoOpciones){

                    dibujarCajaDialogo(g2, escena, textoCompleto);

                    dibujarQuickMenu(g2);

                }

                if(textoCompleto){

                    if(mostrandoOpciones){

                        dibujarOpciones(g2, escena.getOpciones());

                    } else if(gestor.esFinal()){

                        g2.setFont(new Font("Arial",Font.ITALIC,18));

                        String msg = "Click para volver al menú principal";

                        FontMetrics fm = g2.getFontMetrics();

                        g2.setColor(new Color(255,255,255,210));
                        g2.drawString(msg, EscaladoPantalla.ANCHO_VIRTUAL - fm.stringWidth(msg) - 30, 40);

                    }

                }

            }

        }

    }

    private void dibujarCajaDialogo(Graphics2D g2, Escena escena, boolean textoCompleto){

        int cajaAncho = EscaladoPantalla.ANCHO_VIRTUAL - (CAJA_X * 2);
        int cajaY = EscaladoPantalla.ALTO_VIRTUAL - CAJA_ALTO - CAJA_MARGEN_INFERIOR;

        // Sombra suave detrás de la caja, para separarla del fondo
        g2.setColor(new Color(0,0,0,90));
        g2.fillRoundRect(CAJA_X - 3, cajaY + 4, cajaAncho + 6, CAJA_ALTO + 6, 16, 16);

        // Caja ancha y semitransparente pegada a la parte de abajo
        g2.setColor(new Color(8,8,8,205));
        g2.fillRoundRect(CAJA_X, cajaY, cajaAncho, CAJA_ALTO, 14, 14);

        // Línea superior sutil, más clara, como un filo iluminado
        g2.setColor(new Color(255,255,255,35));
        g2.drawLine(CAJA_X + 18, cajaY + 1, CAJA_X + cajaAncho - 18, cajaY + 1);

        g2.setColor(new Color(255,255,255,55));
        g2.drawRoundRect(CAJA_X, cajaY, cajaAncho, CAJA_ALTO, 14, 14);

        int textoX = CAJA_X + 35;
        int textoY = cajaY + 45;

        boolean esNarracion = escena.getPersonaje() == null || escena.getPersonaje().trim().isEmpty();

        if(!esNarracion){

            // Cartel del nombre, flotando arriba a la izquierda de la caja
            g2.setFont(new Font("Arial",Font.BOLD,20));

            FontMetrics fmNombre = g2.getFontMetrics();

            String nombrePersonaje = escena.getPersonaje();
            int anchoCartel = fmNombre.stringWidth(nombrePersonaje) + 44;

            int cartelX = CAJA_X + 20;
            int cartelY = cajaY - 22;

            g2.setColor(new Color(0,0,0,70));
            g2.fillRoundRect(cartelX + 2, cartelY + 3, anchoCartel, 40, 10, 10);

            g2.setColor(new Color(115,25,25));
            g2.fillRoundRect(cartelX, cartelY, anchoCartel, 40, 10, 10);

            g2.setColor(new Color(255,255,255,70));
            g2.drawRoundRect(cartelX, cartelY, anchoCartel, 40, 10, 10);

            g2.setColor(Color.WHITE);
            g2.drawString(nombrePersonaje, cartelX + 22, cartelY + 27);

        }

        g2.setFont(new Font("Arial",Font.PLAIN,22));

        int maxAncho = cajaAncho - 70;

        java.util.List<String> lineas = envolverTexto(g2, textoMostrado, maxAncho);

        int y = textoY;

        for(String linea : lineas){

            // sombra del texto, para que se lea bien sobre cualquier fondo
            g2.setColor(new Color(0,0,0,150));
            g2.drawString(linea, textoX + 1, y + 1);

            g2.setColor(Color.WHITE);
            g2.drawString(linea, textoX, y);

            y += 30;

        }

        // Indicador de "continuar", al estilo Ren'Py: una flechita abajo a la derecha
        // de la caja, que aparece cuando ya se terminó de mostrar el texto
        if(textoCompleto){

            int cx = CAJA_X + cajaAncho - 30;
            int cy = cajaY + CAJA_ALTO - 22;

            int[] xs = {cx - 8, cx + 8, cx};
            int[] ys = {cy - 5, cy - 5, cy + 6};

            g2.setColor(new Color(255,255,255,190));
            g2.fillPolygon(xs, ys, 3);

        }

    }

    // Envuelve el texto en líneas que entran dentro de "maxAncho", respetando
    // los saltos de línea ("\n") que ya pueda traer la escena.
    private java.util.List<String> envolverTexto(Graphics2D g2, String texto, int maxAncho){

        java.util.List<String> lineas = new ArrayList<>();

        FontMetrics fm = g2.getFontMetrics();

        for(String parrafo : texto.split("\n", -1)){

            StringBuilder actual = new StringBuilder();

            for(String palabra : parrafo.split(" ")){

                String prueba = actual.length() == 0 ? palabra : actual + " " + palabra;

                if(fm.stringWidth(prueba) > maxAncho && actual.length() > 0){

                    lineas.add(actual.toString());
                    actual = new StringBuilder(palabra);

                } else {

                    actual = new StringBuilder(prueba);

                }

            }

            lineas.add(actual.toString());

        }

        return lineas;

    }

    private void dibujarBotonGenero(Graphics2D g2, Rectangle r, String texto){

        g2.setColor(new Color(80,80,80));
        g2.fillRoundRect(r.x,r.y,r.width,r.height,12,12);

        g2.setColor(Color.WHITE);
        g2.drawRoundRect(r.x,r.y,r.width,r.height,12,12);

        FontMetrics fm = g2.getFontMetrics();

        int tx = r.x + (r.width - fm.stringWidth(texto)) / 2;
        int ty = r.y + 28;

        g2.drawString(texto,tx,ty);

    }

    private void dibujarOpciones(Graphics2D g2, String[] opciones){

        opcionesRects.clear();

        int alturaFranja = 66;
        int gap = 6;

        int totalHeight = opciones.length * alturaFranja + (opciones.length - 1) * gap;

        int y = (EscaladoPantalla.ALTO_VIRTUAL - totalHeight) / 2;

        for(int i = 0; i < opciones.length; i++){

            Rectangle r = new Rectangle(0, y + i * (alturaFranja + gap), EscaladoPantalla.ANCHO_VIRTUAL, alturaFranja);

            opcionesRects.add(r);

            boolean hover = r.contains(new Point(mouseX, mouseY));

            dibujarFranjaOpcion(g2, r, opciones[i], hover);

        }

    }

    // Franja ancha con degradé que se desvanece en los bordes, como en una
    // novela visual: el fondo desaparece y solo quedan estas tiras con texto
    private void dibujarFranjaOpcion(Graphics2D g2, Rectangle r, String texto, boolean hover){

        Color base = hover ? new Color(70,15,15) : new Color(0,0,0);
        int alfaCentro = hover ? 220 : 175;

        float[] fracciones = {0f, 0.18f, 0.82f, 1f};

        Color[] colores = {
                new Color(base.getRed(), base.getGreen(), base.getBlue(), 0),
                new Color(base.getRed(), base.getGreen(), base.getBlue(), alfaCentro),
                new Color(base.getRed(), base.getGreen(), base.getBlue(), alfaCentro),
                new Color(base.getRed(), base.getGreen(), base.getBlue(), 0)
        };

        LinearGradientPaint degrade = new LinearGradientPaint(
                new Point(r.x, r.y),
                new Point(r.x + r.width, r.y),
                fracciones,
                colores
        );

        g2.setPaint(degrade);
        g2.fillRect(r.x, r.y, r.width, r.height);

        if(hover){

            // líneas finas arriba y abajo, como un marco de selección que brilla
            g2.setColor(new Color(230,190,120,200));
            g2.drawLine(r.x + (int)(r.width*0.2), r.y, r.x + (int)(r.width*0.8), r.y);
            g2.drawLine(r.x + (int)(r.width*0.2), r.y + r.height - 1, r.x + (int)(r.width*0.8), r.y + r.height - 1);

        }

        g2.setFont(new Font("Arial", Font.PLAIN, 24));

        FontMetrics fm = g2.getFontMetrics();

        int tx = r.x + (r.width - fm.stringWidth(texto)) / 2;
        int ty = r.y + r.height / 2 + fm.getAscent() / 2 - 5;

        if(hover){

            // resplandor cálido detrás del texto, para el efecto de "brillo"
            g2.setColor(new Color(255,205,130,130));

            for(int dx = -1; dx <= 1; dx++){
                for(int dy = -1; dy <= 1; dy++){
                    if(dx != 0 || dy != 0){
                        g2.drawString(texto, tx + dx, ty + dy);
                    }
                }
            }

        }

        g2.setColor(hover ? new Color(255,240,215) : new Color(205,200,190));
        g2.drawString(texto, tx, ty);

    }

    // ================== Quick menu (Auto / Skip / Historial / Guardar / Cargar) ==================

    private void dibujarQuickMenu(Graphics2D g2){

        int alturaBarra = 34;

        // franja apenas visible en la base, como en Ren'Py
        g2.setColor(new Color(0,0,0,90));
        g2.fillRect(0, EscaladoPantalla.ALTO_VIRTUAL - alturaBarra, EscaladoPantalla.ANCHO_VIRTUAL, alturaBarra);

        g2.setFont(new Font("Arial", Font.PLAIN, 15));
        FontMetrics fm = g2.getFontMetrics();

        String[] etiquetas = {"Auto", "Skip", "Historial", "Guardar", "Cargar"};
        int espacioEntre = 34;

        int anchoTotal = 0;

        for(String s : etiquetas){
            anchoTotal += fm.stringWidth(s);
        }

        anchoTotal += espacioEntre * (etiquetas.length - 1);

        int x = (EscaladoPantalla.ANCHO_VIRTUAL - anchoTotal) / 2;
        int yBase = EscaladoPantalla.ALTO_VIRTUAL - alturaBarra / 2 + fm.getAscent() / 2 - 3;

        for(String etiqueta : etiquetas){

            int ancho = fm.stringWidth(etiqueta);

            Rectangle r = new Rectangle(x - 8, EscaladoPantalla.ALTO_VIRTUAL - alturaBarra, ancho + 16, alturaBarra);

            boolean activo = (etiqueta.equals("Auto") && autoPlay) || (etiqueta.equals("Skip") && modoSkip);

            switch(etiqueta){
                case "Auto": autoRect = r; break;
                case "Skip": skipRect = r; break;
                case "Historial": historialRect = r; break;
                case "Guardar": guardar = r; break;
                case "Cargar": cargar = r; break;
            }

            dibujarLinkQuickMenu(g2, etiqueta, x, yBase, r, activo);

            x += ancho + espacioEntre;

        }

    }

    private void dibujarLinkQuickMenu(Graphics2D g2, String texto, int x, int y, Rectangle hitbox, boolean activo){

        Point mouse = new Point(mouseX, mouseY);
        boolean hover = hitbox.contains(mouse);

        if(activo){
            g2.setColor(hover ? new Color(255,140,140) : new Color(220,80,80));
        } else {
            g2.setColor(hover ? Color.WHITE : new Color(190,190,190));
        }

        g2.drawString(texto, x, y);

        if(hover || activo){

            FontMetrics fm = g2.getFontMetrics();

            g2.drawLine(x, y + 3, x + fm.stringWidth(texto), y + 3);

        }

    }

    // ================== Historial de diálogos ==================

    private void dibujarHistorial(Graphics2D g2){

        g2.setColor(new Color(10,8,8,235));
        g2.fillRect(0, 0, EscaladoPantalla.ANCHO_VIRTUAL, EscaladoPantalla.ALTO_VIRTUAL);

        g2.setFont(new Font("Serif", Font.BOLD, 36));
        g2.setColor(new Color(200,40,40));
        g2.drawString("Historial", 60, 70);

        g2.setFont(new Font("Arial", Font.PLAIN, 15));
        g2.setColor(new Color(160,160,160));
        g2.drawString("(Click en cualquier lado para cerrar)", 60, 98);

        int margenX = 60;
        int anchoTexto = EscaladoPantalla.ANCHO_VIRTUAL - margenX * 2 - 40;

        int y = 150 - scrollHistorial;

        g2.setFont(new Font("Arial", Font.PLAIN, 19));

        for(String[] entrada : historial){

            String personaje = entrada[0];
            String texto = entrada[1];

            if(personaje != null && !personaje.trim().isEmpty()){

                g2.setFont(new Font("Arial", Font.BOLD, 17));
                g2.setColor(new Color(200,110,110));

                if(y > -30 && y < EscaladoPantalla.ALTO_VIRTUAL){
                    g2.drawString(personaje, margenX, y);
                }

                y += 24;

            }

            g2.setFont(new Font("Arial", Font.PLAIN, 19));

            for(String linea : envolverTexto(g2, texto, anchoTexto)){

                if(y > -30 && y < EscaladoPantalla.ALTO_VIRTUAL){
                    g2.setColor(new Color(220,220,220));
                    g2.drawString(linea, margenX, y);
                }

                y += 27;

            }

            y += 22;

        }

        if(historial.isEmpty()){

            g2.setColor(new Color(150,150,150));
            g2.drawString("Todavía no leíste ningún diálogo en esta partida.", margenX, 150);

        }

    }

    @Override
    public void mousePressed(MouseEvent e){

        Point pReal = escalado.aVirtual(e.getX(), e.getY());

        int x = pReal.x;
        int y = pReal.y;

        if(estado == 0){

            if(!nombre.trim().isEmpty()){
                estado = 1;
                repaint();
            }

            return;

        }

        if(estado == 1){

            Point p = new Point(x,y);

            if(botonMasculino.contains(p)){

                genero = "Masculino";
                iniciarJuego();
                return;

            }

            if(botonFemenino.contains(p)){

                genero = "Femenino";
                iniciarJuego();
                return;

            }

            if(botonOtro.contains(p)){

                genero = "Otro";
                iniciarJuego();
                return;

            }

            return;

        }

        if(estado == 2){

            if(mostrandoHistorial){

                // cualquier click cierra el historial
                mostrandoHistorial = false;
                repaint();

                return;

            }

            if(autoRect != null && autoRect.contains(x,y)){

                autoPlay = !autoPlay;

                if(autoPlay){

                    modoSkip = false;
                    skipTimer.stop();

                    boolean textoCompleto = indiceTexto >= gestor.getEscena().getTexto().length();

                    if(textoCompleto && !gestor.tieneOpciones() && !gestor.esFinal()){
                        autoAdvanceTimer.restart();
                    }

                } else {

                    autoAdvanceTimer.stop();

                }

                repaint();

                return;

            }

            if(skipRect != null && skipRect.contains(x,y)){

                modoSkip = !modoSkip;

                if(modoSkip){

                    autoPlay = false;
                    autoAdvanceTimer.stop();

                    boolean textoCompleto = indiceTexto >= gestor.getEscena().getTexto().length();

                    if(!textoCompleto){

                        // completa de una la línea actual y de ahí sigue encadenando
                        Escena escenaActual = gestor.getEscena();

                        timerTexto.stop();

                        textoMostrado = escenaActual.getTexto();
                        indiceTexto = textoMostrado.length();

                        manejarFinDeTexto();

                    } else if(!gestor.tieneOpciones() && !gestor.esFinal()){

                        skipTimer.restart();

                    }

                } else {

                    skipTimer.stop();

                }

                repaint();

                return;

            }

            if(historialRect != null && historialRect.contains(x,y)){

                mostrandoHistorial = true;
                scrollHistorial = 0;

                repaint();

                return;

            }

            if(guardar != null && guardar.contains(x,y)){

                detenerAutoYSkip();

                ventana.cambiar(new SavePanel(ventana, this, true));

                return;

            }

            if(cargar != null && cargar.contains(x,y)){

                detenerAutoYSkip();

                ventana.cambiar(new SavePanel(ventana, this, false));

                return;

            }

            Escena escenaActual = gestor.getEscena();

            boolean textoCompleto = indiceTexto >= escenaActual.getTexto().length();

            // Si todavía se está "escribiendo" el texto, el click lo completa de una
            if(!textoCompleto){

                timerTexto.stop();

                textoMostrado = escenaActual.getTexto();
                indiceTexto = escenaActual.getTexto().length();

                manejarFinDeTexto();

                repaint();

                return;

            }

            // Si la escena tiene opciones, solo avanza si se clickeó un botón
            if(gestor.tieneOpciones()){

                Point p = new Point(x,y);

                for(int i = 0; i < opcionesRects.size(); i++){

                    if(opcionesRects.get(i).contains(p)){

                        registrarHistorial();

                        gestor.elegir(i);
                        comenzarTexto();
                        repaint();

                        return;

                    }

                }

                // click fuera de los botones de opciones: no hace nada
                return;

            }

            // Si es el final del capítulo, volver al menú principal
            if(gestor.esFinal()){

                detenerAutoYSkip();

                ventana.cambiar(new MenuPrincipal(ventana));

                return;

            }

            registrarHistorial();

            siguienteEscena();

            return;

        }

    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e){

        if(!mostrandoHistorial) return;

        scrollHistorial += e.getWheelRotation() * 40;

        if(scrollHistorial < 0){
            scrollHistorial = 0;
        }

        repaint();

    }

    @Override
    public void keyTyped(KeyEvent e){

        if(estado != 0)
            return;

        char c = e.getKeyChar();

        // Ignorar teclas de control
        if(Character.isISOControl(c))
            return;

        // Limitar longitud del nombre
        if(nombre.length() < 20){

            nombre += c;
            repaint();

        }

    }

    @Override
    public void keyPressed(KeyEvent e){

        // ESC durante la partida: cierra el historial si está abierto,
        // o abre el menú de guardado (con acceso a Ajustes y Menú Principal)
        if(e.getKeyCode() == KeyEvent.VK_ESCAPE && estado == 2){

            if(mostrandoHistorial){

                mostrandoHistorial = false;
                repaint();

                return;

            }

            detenerAutoYSkip();

            ventana.cambiar(new SavePanel(ventana, this, true));

            return;

        }

        if(estado != 0)
            return;

        switch(e.getKeyCode()){

            case KeyEvent.VK_BACK_SPACE:

                if(nombre.length() > 0){

                    nombre = nombre.substring(0,nombre.length()-1);
                    repaint();

                }

                break;

            case KeyEvent.VK_ENTER:

                if(!nombre.trim().isEmpty()){

                    estado = 1;
                    repaint();

                }

                break;

        }

    }

    @Override
    public void keyReleased(KeyEvent e){}

    @Override
    public void mouseClicked(MouseEvent e){}

    @Override
    public void mouseReleased(MouseEvent e){}

    @Override
    public void mouseMoved(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        mouseX = p.x;
        mouseY = p.y;

        repaint();

    }

    @Override
    public void mouseDragged(MouseEvent e){}

    @Override
    public void mouseEntered(MouseEvent e){}

    @Override
    public void mouseExited(MouseEvent e){}
}
