import java.io.*;

public class SaveManager {

    private static final String CARPETA = "saves";

    static {

        File carpeta = new File(CARPETA);

        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

    }

    // ==========================
    // GUARDAR
    // ==========================

    public static void guardar(Guardado guardado, int slot) {

        try {

            File archivo = new File(CARPETA + "/slot" + slot + ".sav");

            ObjectOutputStream salida =
                    new ObjectOutputStream(
                            new FileOutputStream(archivo)
                    );

            salida.writeObject(guardado);

            salida.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    // ==========================
    // CARGAR
    // ==========================

    public static Guardado cargar(int slot) {

        try {

            File archivo = new File(CARPETA + "/slot" + slot + ".sav");

            if (!archivo.exists()) {

                return null;

            }

            ObjectInputStream entrada =
                    new ObjectInputStream(
                            new FileInputStream(archivo)
                    );

            Guardado guardado =
                    (Guardado) entrada.readObject();

            entrada.close();

            return guardado;

        } catch (Exception e) {

            return null;

        }

    }

    // ==========================
    // EXISTE
    // ==========================

    public static boolean existe(int slot) {

        return new File(
                CARPETA + "/slot" + slot + ".sav"
        ).exists();

    }

    // ==========================
    // BORRAR
    // ==========================

    public static void borrar(int slot) {

        File archivo =
                new File(CARPETA + "/slot" + slot + ".sav");

        if (archivo.exists()) {

            archivo.delete();

        }

    }

    // ==========================
    // CANTIDAD DE SLOTS
    // ==========================

    public static final int SLOTS = 5;

}