public class Configuracion {

    private Configuracion(){}

    // Milisegundos entre cada letra en el efecto de máquina de escribir.
    // Menor número = texto más rápido.
    public static int velocidadTexto = 25;

    // Límites de velocidad de texto (en ms por letra), usados por la barra
    // de ajustes. 1 = instantáneo, 50 = lo más lento posible.
    public static final int VELOCIDAD_MIN = 1;
    public static final int VELOCIDAD_MAX = 50;

    // Modo de pantalla: true = pantalla completa, false = ventana
    public static boolean pantallaCompleta = false;

}