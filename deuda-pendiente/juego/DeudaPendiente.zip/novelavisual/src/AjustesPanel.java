import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AjustesPanel extends JPanel implements MouseListener, MouseMotionListener {

    private Ventana ventana;

    // ---- Slider de velocidad de texto ----
    private Rectangle sliderTrackRect;
    private Rectangle sliderThumbRect;
    private boolean arrastrandoSlider = false;

    private static final int THUMB_ANCHO = 18;
    private static final int THUMB_ALTO = 30;

    // ---- Botones de pantalla ----
    private Rectangle ventanaRect;
    private Rectangle pantallaCompletaRect;

    // ---- Volver ----
    private Rectangle volverRect;

    private int mouseX = -1;
    private int mouseY = -1;

    private final EscaladoPantalla escalado = new EscaladoPantalla();

    public AjustesPanel(Ventana ventana){

        this.ventana = ventana;

        setLayout(null);
        setBackground(Color.BLACK);
        setFocusable(true);

        addMouseListener(this);
        addMouseMotionListener(this);

        SwingUtilities.invokeLater(() -> requestFocusInWindow());

    }

    @Override
    protected void paintComponent(Graphics g){

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(Color.BLACK);
        g2.fillRect(0,0,getWidth(),getHeight());

        escalado.actualizar(getWidth(), getHeight());
        escalado.aplicar(g2);

        String titulo = "AJUSTES";

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Serif",Font.BOLD,44));

        FontMetrics fmTitulo = g2.getFontMetrics();
        g2.drawString(titulo,(EscaladoPantalla.ANCHO_VIRTUAL-fmTitulo.stringWidth(titulo))/2,150);

        dibujarSliderVelocidad(g2);
        dibujarSeccionPantalla(g2);

        // Botón volver
        int volverWidth = 300;
        int volverY = 560;

        volverRect = new Rectangle((EscaladoPantalla.ANCHO_VIRTUAL-volverWidth)/2, volverY, volverWidth, 55);

        dibujarBoton(g2, volverRect, "Volver", false);

    }

    // ================== Velocidad del texto (slider) ==================

    private void dibujarSliderVelocidad(Graphics2D g2){

        String sub = "Velocidad del texto";

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial",Font.PLAIN,22));

        FontMetrics fmSub = g2.getFontMetrics();
        g2.drawString(sub,(EscaladoPantalla.ANCHO_VIRTUAL-fmSub.stringWidth(sub))/2,260);

        int trackWidth = 500;
        int trackHeight = 8;
        int trackX = (EscaladoPantalla.ANCHO_VIRTUAL - trackWidth) / 2;
        int trackY = 310;

        sliderTrackRect = new Rectangle(trackX, trackY - trackHeight/2, trackWidth, trackHeight);

        // Riel de fondo
        g2.setColor(new Color(50,50,50));
        g2.fillRoundRect(sliderTrackRect.x, sliderTrackRect.y, sliderTrackRect.width, sliderTrackRect.height, 8, 8);

        // Fracción actual (0 = lento, 1 = instantáneo)
        double f = fraccionDesdeVelocidad(Configuracion.velocidadTexto);

        int thumbX = trackX + (int)(f * trackWidth) - THUMB_ANCHO/2;
        int thumbY = trackY - THUMB_ALTO/2;

        sliderThumbRect = new Rectangle(thumbX, thumbY, THUMB_ANCHO, THUMB_ALTO);

        // Riel relleno hasta el thumb
        g2.setColor(new Color(90,120,190));
        g2.fillRoundRect(sliderTrackRect.x, sliderTrackRect.y, thumbX + THUMB_ANCHO/2 - trackX, sliderTrackRect.height, 8, 8);

        boolean hoverThumb = sliderThumbRect.contains(new Point(mouseX, mouseY)) || arrastrandoSlider;

        g2.setColor(hoverThumb ? new Color(140,170,240) : new Color(110,140,210));
        g2.fillRoundRect(sliderThumbRect.x, sliderThumbRect.y, sliderThumbRect.width, sliderThumbRect.height, 8, 8);

        g2.setColor(Color.WHITE);
        g2.drawRoundRect(sliderThumbRect.x, sliderThumbRect.y, sliderThumbRect.width, sliderThumbRect.height, 8, 8);

        // Etiquetas en los extremos
        g2.setFont(new Font("Arial",Font.PLAIN,15));
        g2.setColor(new Color(160,160,160));
        g2.drawString("Lenta", trackX, trackY + 34);

        FontMetrics fmEtiqueta = g2.getFontMetrics();
        String rapida = "Instantánea";
        g2.drawString(rapida, trackX + trackWidth - fmEtiqueta.stringWidth(rapida), trackY + 34);

        // Etiqueta descriptiva del valor actual, centrada arriba del thumb
        String actual = describirVelocidad(Configuracion.velocidadTexto);

        g2.setFont(new Font("Arial",Font.BOLD,16));
        g2.setColor(Color.WHITE);

        FontMetrics fmActual = g2.getFontMetrics();
        g2.drawString(actual, thumbX + THUMB_ANCHO/2 - fmActual.stringWidth(actual)/2, thumbY - 12);

    }

    // f=0 -> más lento (VELOCIDAD_MAX), f=1 -> instantáneo (VELOCIDAD_MIN)
    private double fraccionDesdeVelocidad(int velocidad){

        int min = Configuracion.VELOCIDAD_MIN;
        int max = Configuracion.VELOCIDAD_MAX;

        double f = (double)(max - velocidad) / (double)(max - min);

        return Math.max(0.0, Math.min(1.0, f));

    }

    private int velocidadDesdeFraccion(double f){

        f = Math.max(0.0, Math.min(1.0, f));

        int min = Configuracion.VELOCIDAD_MIN;
        int max = Configuracion.VELOCIDAD_MAX;

        return (int)Math.round(max - f * (max - min));

    }

    private String describirVelocidad(int velocidad){

        if(velocidad >= 35) return "Lenta";
        if(velocidad >= 18) return "Normal";
        if(velocidad >= 5) return "Rápida";

        return "Instantánea";

    }

    private void actualizarVelocidadDesdeMouse(int x){

        if(sliderTrackRect == null) return;

        double f = (double)(x - sliderTrackRect.x) / (double)sliderTrackRect.width;

        Configuracion.velocidadTexto = velocidadDesdeFraccion(f);

        repaint();

    }

    // ================== Pantalla: ventana / pantalla completa ==================

    private void dibujarSeccionPantalla(Graphics2D g2){

        String sub = "Pantalla";

        g2.setFont(new Font("Arial",Font.PLAIN,22));

        FontMetrics fmSub = g2.getFontMetrics();
        g2.drawString(sub,(EscaladoPantalla.ANCHO_VIRTUAL-fmSub.stringWidth(sub))/2,410);

        int width = 230;
        int height = 55;
        int gap = 20;

        int totalWidth = width * 2 + gap;
        int startX = (EscaladoPantalla.ANCHO_VIRTUAL - totalWidth) / 2;
        int y = 440;

        g2.setFont(new Font("Arial",Font.BOLD,18));

        ventanaRect = new Rectangle(startX, y, width, height);
        pantallaCompletaRect = new Rectangle(startX + width + gap, y, width, height);

        boolean completa = ventana.isPantallaCompleta();

        dibujarBoton(g2, ventanaRect, "Ventana", !completa);
        dibujarBoton(g2, pantallaCompletaRect, "Pantalla completa", completa);

    }

    // ================== Botón genérico ==================

    private void dibujarBoton(Graphics2D g2, Rectangle r, String texto, boolean seleccionado){

        boolean hover = r.contains(new Point(mouseX, mouseY));

        Color fondo;

        if(seleccionado){
            fondo = hover ? new Color(120,150,220) : new Color(90,120,190);
        }else{
            fondo = hover ? new Color(90,90,90) : new Color(35,35,35);
        }

        g2.setColor(fondo);
        g2.fillRoundRect(r.x,r.y,r.width,r.height,16,16);

        g2.setColor(seleccionado || hover ? Color.WHITE : new Color(180,180,180));
        g2.drawRoundRect(r.x,r.y,r.width,r.height,16,16);

        FontMetrics fm = g2.getFontMetrics();

        int tx = r.x + (r.width - fm.stringWidth(texto)) / 2;
        int ty = r.y + r.height / 2 + fm.getAscent() / 2 - 4;

        g2.setColor(Color.WHITE);
        g2.drawString(texto,tx,ty);

    }

    // ================== Interacción ==================

    @Override
    public void mouseClicked(MouseEvent e){}

    @Override
    public void mousePressed(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        if(ventanaRect != null && ventanaRect.contains(p)){

            ventana.setPantallaCompleta(false);
            repaint();

            return;

        }

        if(pantallaCompletaRect != null && pantallaCompletaRect.contains(p)){

            ventana.setPantallaCompleta(true);
            repaint();

            return;

        }

        if(volverRect != null && volverRect.contains(p)){

            ventana.cambiar(new MenuPrincipal(ventana));

            return;

        }

        // Agarra el thumb, o si clickea directo en el riel, salta a esa posición
        if(sliderThumbRect != null && sliderThumbRect.contains(p)){

            arrastrandoSlider = true;

        } else if(sliderTrackRect != null &&
                sliderTrackRect.y - 10 <= p.y && p.y <= sliderTrackRect.y + sliderTrackRect.height + 10 &&
                sliderTrackRect.x <= p.x && p.x <= sliderTrackRect.x + sliderTrackRect.width){

            arrastrandoSlider = true;
            actualizarVelocidadDesdeMouse(p.x);

        }

    }

    @Override
    public void mouseReleased(MouseEvent e){
        arrastrandoSlider = false;
    }

    @Override
    public void mouseDragged(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        mouseX = p.x;
        mouseY = p.y;

        if(arrastrandoSlider){
            actualizarVelocidadDesdeMouse(p.x);
        }

        repaint();

    }

    @Override
    public void mouseMoved(MouseEvent e){

        Point p = escalado.aVirtual(e.getX(), e.getY());

        mouseX = p.x;
        mouseY = p.y;

        repaint();

    }

    @Override
    public void mouseEntered(MouseEvent e){}

    @Override
    public void mouseExited(MouseEvent e){}

}
