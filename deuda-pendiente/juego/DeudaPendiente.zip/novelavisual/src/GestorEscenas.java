import java.util.ArrayList;
import java.util.HashMap;

/**
 * Guión de "EL ACREEDOR" — Capítulo 1: "El que observa desde la sombra".
 *
 * Convenciones de texto:
 *  - "T/N" se reemplaza por el nombre real elegido (hable el/la protagonista
 *    o aparezca mencionad@ en la narración).
 *  - "palabra@" (ej: "sol@") se resuelve a la terminación de género (o/a/e).
 *  - "{masculino|femenino}" (ej: "{el|la}") elige la palabra completa que
 *    corresponda, para pares que no comparten raíz.
 *
 * Elecciones (todas reconvergen, salvo la 1 que tiene un final corto alternativo):
 *  1) ¿Tocar la tumba del sector viejo?
 *  2) ¿Preguntarle a Ramón de quién es la tumba?
 *  3) ¿Leer la nota junto a la vela?
 *  4) ¿A quién contarle lo del stalker? (amigo/a, policía, nadie)
 *  5) ¿Cómo hablarle al Acreedor la primera vez? (desafiante, cautelosa)
 *  6) ¿Qué hacer con la vela de la cocina? (guardarla, tirarla)
 *  7) Última línea del capítulo: exigir respuesta o retroceder
 */
public class GestorEscenas {

    private ArrayList<Escena> escenas = new ArrayList<>();
    private int actual = 0;

    private HashMap<Integer, Integer> saltosForzados = new HashMap<>();

    public GestorEscenas() {
        construir();
    }

    private int e(String personaje, String texto) {
        escenas.add(new Escena(personaje, texto));
        return escenas.size() - 1;
    }

    private void elegirEn(int indiceEscena, String[] opciones, int[] destinos) {
        escenas.get(indiceEscena).setOpciones(opciones, destinos);
    }

    private void marcarFinal(int indice) {
        escenas.get(indice).setEsFinal(true);
    }

    private void forzarSalto(int origen, int destino) {
        saltosForzados.put(origen, destino);
    }

    private void construir() {

        //PRÓLOGO
        e("", "El departamento de T/N tiene esa clase de silencio que solo existe cuando no hay plata ni para pagar el cable. Son las nueve de la noche.");
        e("T/N", "Bueno... otro día, otro cero en la cuenta.");
        e("", "T/N revisa el celular. Treinta y una postulaciones enviadas en los últimos dos meses. Cuatro respuestas. Ninguna oferta.");
        e("Amigo/a", "che, ¿alguna novedad con lo del trabajo?");
        e("T/N", "Nada todavía. Ya empiezo a probar con cualquier cosa, la verdad.");
        e("Amigo/a", "ánimo, algo va a salir. avisame si necesitás algo.");
        e("Anuncio", "\"Se busca vigilante, turno nocturno. Cementerio de Chacarita. Interesados comunicarse al 067-0912-2018.\"");
        e("T/N", "...un cementerio. Por otro lado... nadie más se anota para esto, seguramente. Menos competencia. Y la plata es la plata.");
        e("", "Manda el CV. Dos horas después, el celular vibra.");
        e("Mensaje", "\"Vimos tu CV, encaja con lo que buscamos. Presentate mañana a las 22 hs para la inducción.\"");
        e("T/N", "Un cementerio, de noche, sol@. Genial. Justo lo que pedí en mis oraciones.");

        //CAPÍTULO 1 — Día 1
        e("", "El viaje en subte es tranquilo. El cementerio se ve completamente distinto de noche.");
        e("T/N", "Uf. Bueno. Ya estoy acá, no hay vuelta atrás.");
        e("", "Abre Ramón, un señor grande, de gesto cansado pero amable, con una taza de mate cocido en la mano.");
        e("Ramón", "Vos sos {el|la} que mandó el CV, ¿no? Pasá, pasá. Bienvenid@ a bordo.");
        e("", "Le explica lo básico. Al llegar al sector viejo, baja un poco la voz.");
        e("Ramón", "Ese sector tratá de no meterte mucho ahí, ¿eh? Tierra floja, lápidas que se pueden venir abajo.");
        e("T/N", "Entendido. Nada de aventurarme por ahí.");
        e("Ramón", "Buena decisión. Bueno, ya es hora. Tu horario de salida es a las 6 AM. Cualquier cosa, la oficina siempre está abierta.");
        e("", "T/N enciende la linterna y arranca el primer recorrido.");
        e("T/N", "Bueno... esto no está tan mal. Un poco tétrico, pero nada del otro mundo.");
        e("", "Termina, sin darse cuenta, exactamente en la zona que Ramón le pidió evitar. Al fondo hay una tumba que llama la atención de un modo que no sabría explicar.");
        e("T/N", "Qué raro... es como si esta tumba estuviera más... sola que las demás.");

        // Elección 1
        int e1_p = e("T/N", "¿Limpio la tumba para leer el nombre?");

        int e1_no = e("T/N", "No. Mejor respeto lo que me dijo Ramón, no hace ni un día que empecé.");
        int e1_finCorto = e("", "Fin de ruta corta. Para seguir la historia principal, la curiosidad tiene que ganar.");
        marcarFinal(e1_finCorto);

        int e1_si = e("", "Debajo del musgo, algo brilla. Un relicario viejo, de metal oscurecido, cadena rota. Adentro, un mechón de pelo atado con un hilo sin color.");
        e("T/N", "Uh. Esto se siente como invadir algo muy privado.");
        e("", "Se lo guarda en el bolsillo. El aire cambia — más pesado, más frío de lo que el clima explicaría.");
        e("T/N", "Che, ¿hay alguien ahí?");
        e("", "Nadie responde.");

        elegirEn(e1_p, new String[]{"Tocarla", "No tocarla"}, new int[]{e1_si, e1_no});

        e("T/N", "Encontré esto en el sector viejo.");
        e("", "La cara de Ramón cambia. No es sorpresa — es el gesto de alguien que reconoce algo que prefería no volver a ver.");
        e("Ramón", "...¿de dónde exactamente?");
        e("T/N", "Junto a una tumba sola, al fondo.");
        e("Ramón", "No es por el permiso.");
        e("", "Guarda el relicario en un cajón.");
        e("Ramón", "Te voy a decir una sola cosa, y quiero que la tomes en serio. Si en algún momento sentís que alguien te mira cuando no hay nadie... no lo ignores. Y si te dejan algo, en cualquier lado, mucho menos.");
        e("T/N", "Eso es bastante inquietante para mi segundo día.");

        // Elección 2
        int e2_p = e("T/N", "¿Le pregunto a Ramón de quién es la tumba?");

        int e2_si = e("T/N", "¿Vos sabés de quién es esa tumba?");
        e("", "Ramón duda. Se nota que sopesa cuánto contarle a alguien que recién empieza.");
        e("Ramón", "No hay nombre en la lápida, ¿te fijaste? La borraron a propósito, hace muchísimos años. En el registro del cementerio la tenemos anotada solo como \"N.N. — sector 4, ingreso 1897\". Nadie la visita. Nadie la visitó nunca, en todo el tiempo que llevo yo acá, y eso que llevo veinte años.");
        e("T/N", "¿1897? Eso es re viejo.");
        e("Ramón", "Y hay algo más raro todavía: en los libros más antiguos del cementerio, los que guardamos en el archivo, esa tumba aparece con una anotación al margen que ningún administrador se anima a borrar. Dice, más o menos: \"No remover. No consagrar de nuevo. Dejar como está.\"");
        e("T/N", "¿Quién escribe algo así en un registro de cementerio?");
        int e2_siLast = e("Ramón", "Ni idea. Es letra de otra época. Yo la vi una sola vez, hace años, y no volví a buscarla.");

        int e2_no = e("T/N", "Mejor no. Ya tengo suficiente con lo que vi.");
        int e2_noLast = e("", "Ramón no ofrece la información por su cuenta.");

        elegirEn(e2_p, new String[]{"Sí, preguntás", "No, no preguntás"}, new int[]{e2_si, e2_no});

        int e2_conv = e("Ramón", "Bueno, ya es hora. Andá a descansar.");
        forzarSalto(e2_siLast, e2_conv);
        forzarSalto(e2_noLast, e2_conv);

        // Noche 1
        e("", "El despacho queda vacío. Ramón guarda el relicario con llave y se sienta, cansado.");
        e("Ramón", "No otra vez. Por favor, no otra vez.");
        e("", "Detrás del vidrio esmerilado, una sombra se queda quieta un instante de más antes de irse — sin entrar, sin hacer ruido. Mira el cajón cerrado como quien mira algo que le sacaron de las manos sin permiso, y se va con la certeza fría de que lo que le pertenece siempre vuelve.");

        // Día 2
        e("", "T/N encuentra una flor blanca sobre la almohada al hacer la cama. El tallo, cortado en un ángulo perfecto.");
        e("T/N", "Esto no estaba acá antes de que me fuera a dormir.");
        e("", "Todo cerrado. El cajón de la mesa de luz, apenas entreabierto.");
        e("T/N", "Bueno, esto es raro. Muy raro.");

        e("", "En el sector viejo, el relicario está de vuelta sobre la tumba — limpio, pulido con una dedicación excesiva. Junto a él, una vela encendida que anoche no estaba, y una nota doblada.");
        e("T/N", "Esto no estaba hace un segundo.");

        // Elección 3
        int e3_p = e("T/N", "¿Leo la nota?");

        int e3_no = e("T/N", "No. Ya es mucho por una noche.");

        int e3_si = e("Nota", "\"Sé que sos vos {el|la} que va a quedarse. Los demás nunca se quedan.\"");
        int e3_siLast = e("T/N", "\"Los demás\"... ¿qué demás? ¿Cuántos guardias hubo antes que yo?");

        elegirEn(e3_p, new String[]{"Leerla", "No leerla"}, new int[]{e3_si, e3_no});

        int e3_conv = e("", "Cerca de las cinco, T/N siente que algo {lo|la} observa entre dos mausoleos. La linterna alcanza a rozar una figura alta, quieta, con ropa de otra época. Se queda un segundo de más, dejándose ver a propósito, antes de disolverse.");
        forzarSalto(e3_no, e3_conv);
        forzarSalto(e3_siLast, e3_conv);

        e("T/N", "Esperá... ¡esperá!");
        e("T/N", "...quienquiera que seas, esto ya no se siente como una broma.");

        // Noche 2
        e("", "Esa tarde, antes de que T/N se despierte, el Acreedor ya está en el cuarto. Se queda frente al portarretrato del escritorio: T/N con amigos, riendo.");
        e("Acreedor", "Ese día no estuve. Ninguno de esos días estuve.");
        e("", "Pasa un dedo por el marco, sin tocar el vidrio del todo.");
        e("Acreedor", "Pero puedo esperar. Se me da bien esperar. Llevo practicando mucho más tiempo del que {él|ella} se imagina.");
        e("Acreedor", "Van a dejar de reírse así, tarde o temprano. No hace falta que sea hoy.");
        e("", "Deja el portarretrato exactamente donde estaba y se va antes de que el sol le robe la posibilidad de quedarse un rato más.");

        // Día 3
        e("", "Esa tarde, antes de dormir, T/N nota que el libro que estaba leyendo —a medio terminar, separador en la página ochenta y algo— ya no está donde lo dejó. Está sobre la almohada. Abierto. El separador, movido diez páginas más adelante.");
        e("T/N", "...");
        e("T/N", "Yo no leí esto. Yo no llegué hasta acá.");
        e("", "En la primera página hay algo escrito que antes no estaba, con una letra prolija que no reconoce.");
        e("Nota", "\"Te va a gustar cómo termina. Yo ya lo sé.\"");
        e("T/N", "¿Cómo entraste a mi casa?");
        e("", "Revisa cada rincón. Todo cerrado. Al pasar frente al placard entreabierto, un sonido mínimo {lo|la} hace frenar — el roce de una tela, un crujido que no debería estar ahí con la casa vacía.");
        e("T/N", "Sé que hay algo ahí adentro. Salí.");
        e("", "Nada se mueve. Cuando abre la puerta de un tirón, no hay nadie — solo la ropa colgada, quieta, y un frío que tarda unos segundos de más en irse, como si algo hubiese calculado exactamente cuánto podía quedarse antes de ser visto.");
        e("", "En el espejo del placard, empañado, hay una palabra escrita con un dedo.");
        e("Espejo", "\"mí@\"");
        e("T/N", "...");
        e("T/N", "Esto no es un chiste de mal gusto. Alguien entró a mi casa, tocó mis cosas mientras dormía, y ahora se esconde de mí en mi propio placard como si tuviera derecho a estar acá.");
        e("T/N", "Tengo un stalker. No hay otra explicación. Alguien me está siguiendo, sabe dónde vivo, y se metió acá adentro sin dejar ni un rastro de cómo.");
        e("", "Se sienta en el borde de la cama, con el corazón acelerado. No se le cruza, ni por un segundo, la idea de que la figura del cementerio y esto puedan ser la misma cosa — son, en su cabeza, dos miedos completamente distintos: uno con nombre y explicación posible (\"una persona, un desquiciado, alguien que me vio en algún lado y se obsesionó\"), y otro sin ninguna explicación (\"algo\" que aparece entre las tumbas y que preferiría no pensar demasiado).");

        // Elección 4
        int e4_p = e("T/N", "¿A quién le cuento lo del stalker?");

        int e4_amigo = e("T/N", "Che, necesito contarte algo. Creo que tengo un stalker.");
        e("Amigo/a", "¿QUÉ? ¿Estás segur@? ¿Llamaste a la policía?");
        e("T/N", "Todavía no. Pensé que capaz me estaba volviendo loc@, pero encontré cosas movidas, una palabra escrita en el espejo...");
        e("Amigo/a", "Eso no es \"capaz te estás volviendo loca\", eso es gravísimo. ¿Cambiaste la cerradura por lo menos? Y esta semana quedate en casa de alguien, no te quedes ahí sol@.");
        e("T/N", "No tengo un peso para un cerrajero ahora, la verdad. Voy a trabar la puerta con una silla o algo, ya está.");
        int e4_amigoLast = e("Amigo/a", "T/N, en serio. Avisame cualquier cosa a cualquier hora, ¿eh? Lo digo en serio.");

        int e4_policia = e("", "T/N hace la denuncia. El oficial toma nota, sin mucho entusiasmo, de \"posible intrusión sin daños ni robo, sin señales de forzamiento\".");
        e("Oficial", "Sin cámaras, sin testigos y sin nada robado, la verdad, es difícil que podamos hacer mucho. Pero quedó asentado. Si pasa de nuevo, llamá enseguida.");
        int e4_policiaLast = e("T/N", "Genial. Quedó \"asentado\". Buenísimo.");

        int e4_nadie = e("T/N", "No. Si lo cuento, va a sonar a que estoy paranoic@. Mejor lo manejo yo sol@.");

        elegirEn(e4_p, new String[]{"A un amigo/a", "A la policía", "A nadie"}, new int[]{e4_amigo, e4_policia, e4_nadie});

        int e4_conv = e("T/N", "Che, Ramón... esto no tiene que ver con el cementerio, pero necesito contarte igual. Creo que tengo un stalker. Entraron a mi casa. Movieron mis cosas. Escribieron en un espejo.");
        forzarSalto(e4_amigoLast, e4_conv);
        forzarSalto(e4_policiaLast, e4_conv);
        forzarSalto(e4_nadie, e4_conv);

        e("", "Ramón se pone serio, pero de un modo distinto a como se pone serio con lo del sector viejo — más práctico, más de \"esto es un problema humano\".");
        e("Ramón", "¿Hiciste la denuncia?");
        e("Ramón", "Mirá, no te puedo ayudar mucho con eso, la verdad. Pero cuidate. Y — esto te lo digo aparte, no sé si tiene que ver — lo que sea que ronda por acá, en el cementerio... no suele salir del predio. Nunca lo vi hacerlo. Así que dudo que sea lo mismo.");
        e("T/N", "Menos mal. Ya bastante tengo con un problema a la vez.");

        // Día 4
        e("", "T/N vuelve al cementerio decidid@ a que la figura se muestre de una vez. Esta noche, en su cabeza, viene a resolver un problema — el del cementerio — sin ninguna sospecha de que podría estar por encontrarse cara a cara con el otro.");
        e("T/N", "¡Salí! Ya sé que estás ahí. Salí y hablame de frente, si tenés algo para decirme.");
        e("", "La figura aparece a menos de dos metros.");
        e("Acreedor", "Al fin.");
        e("T/N", "¿Al fin qué?");
        e("Acreedor", "Al fin dejás de fingir que no me sentís.");

        // Elección 5
        int e5_p = e("T/N", "¿Cómo le hablo?");

        int e5_desafiante = e("T/N", "Mirá, no sé qué sos ni qué querés, pero no me asustás. Así que hablá de una vez o dejame en paz.");
        e("", "Algo cruza brevemente la expresión del Acreedor — no es enojo, es más parecido a interés.");
        int e5_desafianteLast = e("Acreedor", "No te asusto. Interesante. Eso no me lo había dicho nadie antes que vos.");

        int e5_cautelosa = e("T/N", "No quiero problemas. Solo necesito entender qué es lo que está pasando acá, y si hay algo que pueda hacer para que esto no siga.");
        int e5_cautelosaLast = e("Acreedor", "(un silencio más largo de lo normal) Eso ya es más de lo que me preguntó nadie.");

        elegirEn(e5_p, new String[]{"Desafiante", "Cauteloso/a"}, new int[]{e5_desafiante, e5_cautelosa});

        int e5_conv = e("T/N", "Tenés que dejar de hacer esto. Lo de mirarme sin que te vea, lo de dejarme cosas en esa tumba como si yo te hubiese pedido algo. Esto no es cariño, ni un gesto lindo. Es invasivo, y pasa acá, en mi trabajo, todas las noches.");
        forzarSalto(e5_desafianteLast, e5_conv);
        forzarSalto(e5_cautelosaLast, e5_conv);

        e("Acreedor", "Lo tengo en cuenta.");
        e("T/N", "\"Lo tengo en cuenta\" no es lo mismo que \"lo voy a dejar de hacer\".");
        e("Acreedor", "No. No lo es.");
        e("T/N", "¿Por lo menos me vas a explicar qué sos? ¿Qué querés?");
        e("Acreedor", "Todavía no.");
        e("T/N", "Necesito que te alejes de mí.");
        e("Acreedor", "Ya te dije que no puedo prometerte eso.");
        e("T/N", "¿Por qué no?");
        e("Acreedor", "Porque todavía no terminé de entender qué sos vos para mí. Y hasta que lo entienda, no me pidas que me vaya.");
        e("", "El campanazo marca las seis.");
        e("Acreedor", "Andá. Ya casi amanece.");
        e("T/N", "Esto no termina acá.");
        e("Acreedor", "No. No termina.");
        e("", "Antes de irse del todo:");
        e("Acreedor", "Nos vemos mañana, T/N.");

        // Noche 3
        e("", "T/N vuelve agotad@. El sueño {lo|la} vence casi de inmediato.");
        e("", "El Acreedor está ahí, de pie junto a la cama, sin la distancia prudente que mantiene cuando sabe que lo miran.");
        e("Acreedor", "Así dormís. Nunca te había visto así. Sin esa cara que ponés cuando me descubrís. Sin la desconfianza.");
        e("", "Deja el portarretrato boca abajo sobre la mesa.");
        e("Acreedor", "Ellos te tienen así. Riéndote de verdad. A mí me das la versión asustada. No hace falta que se rían tanto. No hace falta que tengan tanto de vos.");
        e("", "Se acerca un paso más.");
        e("Acreedor", "¿Sabés qué es lo peor de esperar tanto tiempo a alguien? Que uno empieza a practicar. A ensayar qué decir, qué no decir. Ahí afuera te contesto con monosílabos, como si pudiera vivir sin la respuesta. Acá no me alcanzan las palabras.");
        e("Acreedor", "Los que estuvieron antes que vos no entendieron nada. Se asustaban rápido, se iban rápido. Vos sos la primera que se queda a pesar del miedo. Tiene que ser una señal de que por fin elegí bien.");
        e("", "Estira la mano y aparta un mechón de pelo de la cara de T/N.");
        e("Acreedor", "No voy a lastimarte. Eso quiero que lo tengas claro, aunque no me estés escuchando ahora. Pero tampoco voy a dejar que te vayas. Ni vos, ni nada de lo que sea tuyo. Ya empecé a hacerme lugar acá. No pienso devolver ese lugar así nomás.");
        e("", "T/N suspira en sueños. El Acreedor se relaja, aliviado de que no se despierte.");
        e("Acreedor", "Cuando estás despiert@ me tratás como una amenaza. Y tenés razón, probablemente. Pero acá sos mí@ de un modo que ahí afuera nunca me vas a dejar tener.");
        e("", "Saca una foto pequeña del cajón: T/N de más joven, junto a alguien que ya no aparece en su vida actual.");
        e("Acreedor", "Este también me lo voy a quedar. No creo que lo extrañes tanto como para notarlo.");
        e("", "Se la guarda entre la ropa, deja algo nuevo sobre la mesa de luz, y se desvanece sin ruido.");

        // Día 5
        e("", "T/N pasa el día dando vueltas al mismo pensamiento: el stalker, si vale la pena gastar en cambiar la cerradura aunque no le sobre un peso, y por separado, si vale la pena seguir en un trabajo donde hay \"algo\" en el sector viejo.");
        e("", "A la tardecita busca las llaves en el cajón de siempre. No están.");
        e("T/N", "Qué raro. Siempre las dejo acá.");
        e("", "Las encuentra sobre la mesa de luz.");
        e("T/N", "...yo no las dejé ahí. Este stalker cada vez se pone más cómodo.");
        e("", "En la cocina, sobre la mesada: la misma vela del cementerio, apagada, esperando.");
        e("T/N", "No. No, no, no.");
        e("", "Puerta cerrada con llave. Ninguna ventana forzada.");
        e("T/N", "¿Cómo entró OTRA VEZ?");

        // Elección 6
        int e6_p = e("T/N", "¿Qué hago con la vela?");

        int e6_guardar = e("T/N", "Esto lo guardo. Si vuelvo a hacer la denuncia, que quede constancia de algo físico, al menos.");
        int e6_guardarLast = e("", "Guarda la vela en una bolsa, con cuidado de no tocarla de más.");

        int e6_tirar = e("T/N", "No la quiero ni cerca. A la basura.");
        int e6_tirarLast = e("", "La tira sin pensarlo dos veces. Esa misma noche, en el sector viejo, la vela vuelve a estar sobre la tumba, intacta, como si nunca se hubiese ido.");

        elegirEn(e6_p, new String[]{"Guardarla como prueba", "Tirarla"}, new int[]{e6_guardar, e6_tirar});

        int e6_conv = e("T/N", "Se terminó. Hoy le digo al Acreedor, en el cementerio, que esto se acaba, sea lo que sea. Y si no entiende, renuncio. No me importa la plata.");
        forzarSalto(e6_guardarLast, e6_conv);
        forzarSalto(e6_tirarLast, e6_conv);

        // Día 6 — confrontación final
        e("T/N", "¡SALÍ! ¡Salí de donde estés, ahora!");
        e("", "Camina directo hacia el sector viejo.");
        e("T/N", "Necesito que pares con esto. Sentirme observad@ acá adentro, las cosas que aparecen en las tumbas... necesito que entiendas que esto termina hoy.");
        e("Acreedor", "Te escucho.");
        e("Acreedor", "No puede terminar.");
        e("T/N", "¿Por qué no?");
        e("Acreedor", "Porque ya no sé estar sin mirarte. Cada noche que no venís, cuento las horas hasta que volvés. Y cuando volvés, cuento los minutos hasta que te vas.");
        e("T/N", "Eso no es amor, ni cariño, ni nada de lo que pienses que es. Eso es enfermo.");
        e("Acreedor", "Puede ser. No sé distinguir ya una cosa de la otra.");
        e("T/N", "Renuncio. Mañana mismo le aviso a Ramón que renuncio.");
        e("", "Algo cambia de verdad en el rostro del Acreedor. No es enojo. Es algo más frío, más calculado.");
        e("Acreedor", "Podés intentarlo.");
        e("T/N", "¿\"Intentarlo\"? No es que voy a pedir permiso.");
        e("Acreedor", "No hace falta que lo pidas. Pero un lugar deja de importar cuando lo que te sigue ya no está atado a ese lugar.");
        e("T/N", "¿Me estás diciendo que si dejo el trabajo, me vas a seguir igual?");

        // Elección 7
        int e7_p = e("T/N", "¿Cómo cierro esto?");

        int e7_contestame = e("T/N", "No te vayas sin contestarme. Ahora. ¿Me vas a seguir o no?");
        e("", "El Acreedor {lo|la} mira, fijo, sin parpadear, un tiempo insoportablemente largo. La falta de respuesta es, de por sí, la respuesta más aterradora que podría haber dado.");
        e("", "El campanazo marca las seis.");
        e("Acreedor", "Andá. Ya casi amanece.");
        int e7_contestameLast = e("T/N", "No. Esta vez no. Necesito una respuesta.");

        int e7_retroceder = e("", "T/N no insiste. Da un paso atrás, sin dejar de mirarlo, con la sensación de que insistir ahora sería peor que quedarse con la duda.");
        e("T/N", "(para sí) ... No. Mejor no sé la respuesta todavía.");
        e("", "El campanazo marca las seis.");
        e("Acreedor", "Andá. Ya casi amanece.");
        int e7_retrocederLast = e("T/N", "Está bien. Pero esto no se olvida.");

        elegirEn(e7_p, new String[]{"\"Contestame. Ahora.\"", "Retroceder en silencio"}, new int[]{e7_contestame, e7_retroceder});

        int e7_conv = e("Acreedor", "Y la vas a tener. Pero no hoy.");
        forzarSalto(e7_contestameLast, e7_conv);
        forzarSalto(e7_retrocederLast, e7_conv);

        e("", "Retrocede hacia las sombras.");
        e("Acreedor", "Nos vemos mañana, T/N. Siempre nos vamos a ver mañana. Estés donde estés.");

        // Fin del capítulo
        e("", "T/N se queda sol@ en medio del sector viejo, con la luz del amanecer pegándole en la cara. Tiene, en su cabeza, dos problemas sin resolver: una presencia en el cementerio que quizás nunca va a poder explicar del todo, y un stalker en su vida real que quizás nunca va a poder atrapar. No se le cruza, ni por un segundo, que sean la misma persona.");
        int fin = e("", "\"Nos vemos mañana. Estés donde estés.\"\n\nCONTINUARÁ EN EL CAPÍTULO 2");
        marcarFinal(fin);

    }

    public Escena getEscena() { return escenas.get(actual); }
    public boolean tieneOpciones() { return escenas.get(actual).tieneOpciones(); }
    public boolean esFinal() { return escenas.get(actual).isEsFinal(); }

    public void siguiente() {
        if (saltosForzados.containsKey(actual)) {
            actual = saltosForzados.get(actual);
            return;
        }
        if (actual < escenas.size() - 1) {
            actual++;
        }
    }

    public void elegir(int indice) {
        Escena esc = escenas.get(actual);
        if (!esc.tieneOpciones()) return;
        actual = esc.getDestinos()[indice];
    }

    public int getIndex() { return actual; }
    public void setIndex(int i) { actual = i; }

    public void aplicarNombre(String nombre) {
        for (Escena esc : escenas) esc.aplicarNombre(nombre);
    }

    public void aplicarGenero(String genero) {
        for (Escena esc : escenas) esc.aplicarGenero(genero);
    }
}
