import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.util.Random;

// Fondo de bosque nocturno reutilizable en distintas pantallas del juego.
public class Escenografia {

    private Escenografia(){}

    public static void dibujarBosque(Graphics2D g2, int w, int h){

        GradientPaint cielo = new GradientPaint(
                0f, 0f, new Color(6,9,8),
                0f, h, new Color(18,22,19)
        );
        g2.setPaint(cielo);
        g2.fillRect(0,0,w,h);

        // Troncos de árboles a los costados (semilla fija: siempre el mismo paisaje)
        Random rnd = new Random(7);

        g2.setColor(new Color(9,11,9));

        for(int i = 0; i < 16; i++){

            int x = rnd.nextInt(w);
            int ancho = 14 + rnd.nextInt(24);

            if(x > w*0.26 && x < w*0.66) continue;

            g2.fillRect(x, 0, ancho, h);

        }

        // Niebla, en capas
        for(int i = 0; i < 5; i++){

            int fy = (int)(h*0.32f) + i * 55;

            g2.setColor(new Color(200,205,200, 16));
            g2.fillOval(-200 + i*140, fy, 950, 110);

        }

    }

}
